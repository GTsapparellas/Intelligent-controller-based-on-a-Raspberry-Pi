from Utils import Gaussmeter
from Utils import PowerSupplier
from Interfaces import serialInterface
from Interfaces import gpibInterface
import time

''' MagnetCalibration class for Intelligent Controller based on Raspberry Pi project.
    Ascending and Descending calibrations are included for more accurate
    correlation between electrical current and magnetic field values.
# @author: Giorgos Tsapparellas
# @date: 5 August 2019
# @version: 1.0 '''

class MagnetCalibration:
    
    ''' __init__ function for preparing magnet calibration.
        Default is set to +- 3 Amps (current limit) '''
    def __init__(self):
        global gaussmeter, power_supplier, ser, gpib
        
        ''' Create instances for LakeShore425_Gauss,
            KepcoBOP, SerialInterface and GpibInterface classes '''
        gaussmeter = Gaussmeter.LakeShore425_Gauss()
        power_supplier = PowerSupplier.KepcoBOP()
        ser = serialInterface.SerialInterface()
        gpib = gpibInterface.GpibInterface()
        
        ''' Default magnet calibration is set to
            +- 3 Amps (current limit) '''
        self.a_ascending = 1.20
        self.a_descending = 1.52
        self.b_ascending = 282.230769231
        self.b_descending = 282.249230769
        
        ''' Correlation parameters are set to 0 '''
        n_ascending = 0
        n_descending = 0
        self.PosCurrLim = 0.0
        self.NegCurrLim = 0.0
        XY_Asceding = 0.0
        XX_Asceding = 0.0
        XY_Descending = 0.0
        XX_Descending = 0.0
        
        ''' Current precision is set to 0.25 '''
        self.ELECTRICAL_CURRENT_PRECISION = 0.25
        
        ''' Delay is set to 2 (seconds) '''
        self.DELAY = 2
        
        ''' Prepare remote communication with the power supplier. '''
        gpib.gpibWriteOnly(power_supplier.c_SetRemoteCommunication(1))
        gpib.gpibWriteOnly(power_supplier.c_SetVoltageLevel("20E0"))
        gpib.gpibWriteOnly(power_supplier.sendMultipleKepcoSCPI(power_supplier.c_OperatingMode("CURR"), power_supplier.c_EDOutput(1)))
        gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel("3E0"))
        gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel("0E0"))
       
    ''' Set the positive current limit. 
    # @param: invar - enter invar as positive current limit '''
    def SetPositiveCurrentLimit(self, invar):
        self.PosCurrLim = invar
        
    ''' Set the negative current limit. 
    # @param: invar - enter invar as negative current limit '''
    def SetNegativeCurrentLimit(self, invar):
        self.NegCurrLim = -invar
        
    ''' Get the positive current limit. 
	# @return: positive current limit '''
    def GetPositiveCurrentLimit(self):
        return self.PosCurrLim
    
    ''' Get the negative current limit. 
	# @return: negative current limit '''
    def GetNegativeCurrentLimit(self):
        return self.NegCurrLim
        
    ''' Get the a_ascending variable
		used for calibration procedure. 
	# @return: a_ascending '''
    def GetA_Ascending(self):
        return self.a_ascending
		
	''' Get the b_ascending variable
		used for calibration procedure. 
	# @return: b_ascending '''
    def GetB_Ascending(self):
        return self.b_ascending
		
    ''' Get the a_descending variable
		used for calibration procedure. 
	# @return: a_descending '''    
    def GetA_Descending(self):
        return self.a_descending
       
	''' Get the b_descending variable
		used for calibration procedure. 
	# @return: b_descending '''
    def GetB_Descending(self):
        return self.b_descending

	''' Ascending calibration procedure. '''		
    def asceding_calibration(self):
        i = self.NegCurrLim
        counterA = 0
        sumX_Ascending = 0.0
        sumY_Ascending = 0.0
        sumXY_Ascending = 0.0
        sumXX_Ascending = 0.0
        while (i >= self.NegCurrLim and i <= self.PosCurrLim):
            electrical_current = str(i) + "E0"
            gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel(str(electrical_current)))
            time.sleep(self.DELAY)
            magnetic_field = float(ser.serialFullCommunication(gaussmeter.q_FieldReading()))
            time.sleep(self.DELAY)
            XY_Ascending = i * magnetic_field
            XX_Ascending = i * i
            sumX_Ascending = sumX_Ascending + i
            sumY_Ascending = sumY_Ascending + magnetic_field
            sumXY_Ascending = sumXY_Ascending + XY_Ascending
            sumXX_Ascending = sumXX_Ascending + XX_Ascending
            i = i + self.ELECTRICAL_CURRENT_PRECISION
            counterA = counterA + 1
        n_ascending = counterA
        self.a_ascending = (sumY_Ascending * sumXX_Ascending - sumX_Ascending * sumXY_Ascending)/(n_ascending * sumXX_Ascending - sumX_Ascending * sumX_Ascending)
        self.b_ascending = (n_ascending * sumXY_Ascending - sumX_Ascending * sumY_Ascending)/(n_ascending * sumXX_Ascending - sumX_Ascending * sumX_Ascending)

	''' Descending calibration procedure. '''		
    def desceding_calibration(self):
        i = self.PosCurrLim
        counterD = 0
        sumX_Descending = 0.0
        sumY_Descending = 0.0
        sumXY_Descending = 0.0
        sumXX_Descending = 0.0
        while (i <= self.PosCurrLim and i >= self.NegCurrLim):
            electrical_current = str(i) + "E0"
            gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel(str(electrical_current)))
            time.sleep(self.DELAY)
            magnetic_field = float(ser.serialFullCommunication(gaussmeter.q_FieldReading()))
            time.sleep(self.DELAY)
            XY_Descending = i * magnetic_field
            XX_Descending = i * i
            sumX_Descending = sumX_Descending + i
            sumY_Descending = sumY_Descending + magnetic_field
            sumXY_Descending = sumXY_Descending + XY_Descending
            sumXX_Descending = sumXX_Descending + XX_Descending
            i = i - self.ELECTRICAL_CURRENT_PRECISION
            counterD = counterD + 1
        n_descending = counterD
        self.a_descending = (sumY_Descending * sumXX_Descending - sumX_Descending * sumXY_Descending)/(n_descending * sumXX_Descending - sumX_Descending * sumX_Descending)
        self.b_descending = (n_descending * sumXY_Descending - sumX_Descending * sumY_Descending)/(n_descending * sumXX_Descending - sumX_Descending * sumX_Descending)
    