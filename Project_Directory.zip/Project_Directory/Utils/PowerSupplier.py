''' KepcoBOP class.
    Commands and Queries
    for communicating with the 
    power supplier.
# @author: Giorgos Tsapparellas
# @date: 15 July 2019
# @version: 1.0 '''

class KepcoBOP:
    
    ''' __init__ function for preparing the KepcoBOP class. '''
    def __init__(self):
        
        ''' Data separator, message_unit_separator, root_specifier and comma indicators. '''
        self.data_separator = " "
        self.message_unit_separator = ";"
        self.root_specifier = ":"
        self.comma = ","

        ''' Common SCPI-IEEE 488.2 commands/queries '''
        self.cls_command = "*CLS"
        self.ese_command = "*ESE "
        self.ese_query = "*ESE?"
        self.esr_query = "*ESR?"
        self.idn_query = "*IDN?"
        self.opc_command = "*OPC"
        self.opc_query = "*OPC?"
        self.opt_query = "*OPT?"
        self.rcl_command = "*RCL "
        self.rst_command = "*RST"
        self.sav_command = "*SAV "
        self.sre_command = "*SRE "
        self.sre_query = "*SRE?"
        self.stb_query = "*STB?"
        self.trg_command = "*TRG"
        self.tst_query = "*TST?"
        self.wai_command = "*WAI"

        ''' Calibration SCPI commands/queries. '''
        self.cal_cpr_command = "CAL:CPR "
        self.cal_stat_command = "CAL:STAT "
        self.cal_stat_query = "CAL[:STAT]?"
        self.cal_curr_command = "CAL:CURR "
        self.cal_data_command = "CAL:DATA "
        self.cal_dpot_command = "CAL:DPOT "
        self.cal_lcurr_command = "CAL:LCURR "
        self.cal_lvolt_command = "CAL:LVOLT "
        self.cal_save_command = "CAL:SAVE"
        self.cal_volt_command = "CAL:VOLT "
        self.cal_vpr_command = "CAL:VPR "
        self.cal_zero_command = "CAL:ZERO"

        ''' Other SCPI commands/queries. '''
        self.init_imm_command = "INIT[:IMM]"
        self.init_cont_command = "INIT:CONT "
        self.init_cont_query = "INIT:CONT?"
        self.meas_curr_query = "MEAS:CURR?"
        self.meas_volt_query = "MEAS:VOLT?"
        self.outp_command = "OUTP "
        self.outp_query = "OUTP?"
        self.func_mode_command = "FUNC:MODE "
        self.func_mode_query = "FUNC:MODE?"
        self.func_mode_trigger_command = "FUNC:MODE:TRIG "
        self.func_mode_trigger_query = "FUNC:MODE:TRIG?"
        self.list_cle_command = "LIST:CLE"
        self.list_coun_command = "LIST:COUN "
        self.list_coun_query = "LIST:COUN?"
        self.list_coun_skip_command = "LIST:COUN:SKIP "
        self.list_coun_skip_query = "LIST:COUN:SKIP?"
        self.list_curr_command = "LIST:CURR "
        self.list_curr_query = "LIST:CURR?"
        self.list_curr_poin_query = "LIST:CURR:POIN?"
        self.list_dir_command = "LIST:DIR "
        self.list_dir_query = "LIST:DIR?"
        self.list_dwel_command = "LIST:DWEL "
        self.list_dwel_query = "LIST:DWEL?"
        self.list_dwel_poin_query = "LIST:DWEL:POIN?"
        self.list_gen_command = "LIST:GEN "
        self.list_gen_query = "LIST:GEN?"
        self.list_quer_command = "LIST:QUER "
        self.list_quer_query  = "LIST:QUER?"
        self.list_mode_command  = "LIST:MODE "
        self.list_mode_query = "LIST:MODE?"
        self.list_seq_command  = "LIST:SEQ "
        self.list_seq_query = "LIST:SEQ?"
        self.list_volt_command = "LIST:VOLT "
        self.list_volt_query = "LIST:VOLT?"
        self.list_volt_poin_query = "LIST:VOLT:POIN?"
        self.curr_command = "CURR "
        self.curr_query = "CURR?"
        self.curr_mode_command = "CURR:MODE "
        self.curr_mode_query = "CURR:MODE?"
        self.curr_rang_command = "CURR:RANG "
        self.curr_rang_query = "CURR:RANG?"
        self.curr_rang_auto_command = "CURR:RANG:AUTO "
        self.curr_trig_command = "CURR:TRIG "
        self.curr_trig_query = "CURR:TRIG?"
        self.volt_command = "VOLT "
        self.volt_query = "VOLT?"
        self.volt_mode_command = "VOLT:MODE "
        self.volt_mode_query = "VOLT:MODE?"
        self.volt_rang_command = "VOLT:RANG "
        self.volt_rang_query = "VOLT:RANG?"
        self.volt_rang_auto_command = "VOLT:RANG:AUTO "
        self.volt_trig_command = "VOLT:TRIG "
        self.volt_trig_query = "VOLT:TRIG?"
        self.stat_oper_cond_query = "STAT:OPER:COND?"
        self.stat_oper_enab_command = "STAT:OPER:ENAB "
        self.stat_oper_enab_query = "STAT:OPER:ENAB?"
        self.stat_oper_query = "STAT:OPER?"
        self.stat_pres_command = "STAT:PRES"
        self.stat_ques_query = "STAT:QUES?"
        self.stat_ques_cond_query = "STAT:QUES:COND?"
        self.stat_ques_enab_command = "STAT:QUES:ENAB "
        self.stat_ques_enab_query = "STAT:QUES:ENAB?"
        self.syst_beep_command = "SYST:BEEP"
        self.syst_comm_ser_echo_command = "SYST:COMM:SER:ECHO "
        self.syst_comm_ser_echo_query = "SYST:COMM:SER:ECHO?"
        self.syst_comm_ser_pace_command = "SYST:COMM:SER:PACE "
        self.syst_comm_ser_pace_query = "SYST:COMM:SER:PACE?"
        self.syst_err_query = "SYST:ERR?"
        self.syst_err_code_query = "SYST:ERR:CODE?"
        self.syst_err_code_all_query = "SYST:ERR:CODE:ALL?"
        self.syst_pass_cen_command = "SYST:PASS:CEN "
        self.syst_pass_cdis_command = "SYST:PASS:CDIS "
        self.syst_pass_new_command = "SYST:PASS:NEW "
        self.syst_pass_stat_query = "SYST:PASS:STAT?"
        self.syst_rem_command = "SYST:REM "
        self.syst_rem_query = "SYST:REM?"
        self.syst_sec_imm_command = "SYST:SEC:IMM"
        self.syst_set_command = "SYST:SET "
        self.syst_set_query = "SYST:SET?"
        self.syst_vers_query = "SYST:VERS?"

        ''' Defaults for parameters used in KepcoBOP class functions later on. '''
        self.OFF = 0
        self.ON = 1

        self.EVENT_STATUS_ENABLE_REGISTER_MIN = 0
        self.EVENT_STATUS_ENABLE_REGISTER_MAX = 255

        self.MEMORY_LOCATION_MIN = 1
        self.MEMORY_LOCATION_MAX = 99

        self.SERVICE_REQUEST_ENABLE_REGISTER_MIN = 0
        self.SERVICE_REQUEST_ENABLE_REGISTER_EXCEPT = 6
        self.SERVICE_REQUEST_ENABLE_REGISTER_MAX = 255

        self.VOLT_STRING = "VOLT"
        self.CURR_STRING = "CURR"

        self.TIMES_TO_EXEC_MIN = 0
        self.TIMES_TO_EXEC_MAX = 255

        self.SKIP_STEPS_MIN = 0
        self.SKIP_STEPS_MAX = 255

        self.UP_STRING = "UP"
        self.DOWN_STRING = "DOWN"

        self.ACTIVE_FOR_MIN = 0.0005
        self.ACTIVE_FOR_MAX = 10

        self.SEQ_STRING = "SEQ"
        self.DSEQ_STRING = "DSEQ"

        self.LOCATION_TO_BE_QUERIED_MIN = 0
        self.LOCATION_TO_BE_QUERIED_MAX = 1001

        self.SLOW_STRING = "SLOW"
        self.FAST_STRING = "FAST"

        self.LIST_STRING = "LIST"
        self.FIX_STRING = "FIX"
        self.TRAN_STRING = "TRAN"

        self.TRAN_SECONDS_MIN = 0
        self.TRAN_SECONDS_MAX = 10

        self.RANGE_FULL_SCALE = 1
        self.RANGE_QUARTER_SCALE = 4

        self.REGISTER_BITS_MIN = 0
        self.REGISTER_BITS_MAX = 1313

        self.ON_STRING = "ON"
        self.OFF_STRING = "OFF"

        self.XON_STRING = "XON"
        self.NONE_STRING = "NONE"

        self.CM0_STRING = "CM0"
        self.CM1_STRING = "CM1"

        self.DC0_STRING = "DC0"
        self.DC1_STRING = "DC1"

        self.LF0_STRING = "LF0"
        self.LF1_STRING = "LF1"

        self.RO0_STRING = "RO0"
        self.RO1_STRING = "RO1"

        self.MIN_SCPI_MSGS = 1

        self.MIN_STRING = "MIN"
        self.MAX_STRING = "MAX"
        self.ZERO_STRING = "ZERO"
        
    ''' q_ functions referred to the query related functions 
        and c_ functions referred to the command related functions.'''
        
    ''' c_ClearStatus command function. '''
    def c_ClearStatus(self):
        return self.cls_command

    ''' c_EventStatusEnable command function. '''       
    def c_EventStatusEnable(self, event_status_enable_register):
        if (event_status_enable_register == str(event_status_enable_register)
            or event_status_enable_register != int(event_status_enable_register)
           ):
           raise TypeError ("Enter a positive whole number (int) of bits " +
                            "from 0 to 255. Default value is 0." +
                            " Value entered: {}. "
                            .format(event_status_enable_register) +
                            "Refer to help function for guidance of usage.")
        elif (event_status_enable_register <
              self.EVENT_STATUS_ENABLE_REGISTER_MIN
              or
              event_status_enable_register >
              self.EVENT_STATUS_ENABLE_REGISTER_MAX):
              raise ValueError ("Enter a positive whole number (int) of bits " +
                                "from 0 to 255. Default value is 0." +
                                " Value entered: {}. "
                                .format(event_status_enable_register) +
                                "Refer to help function for guidance of usage.")
        else:
            return self.ese_command + str(event_status_enable_register)

    ''' q_EventStatusEnable query function. '''         
    def q_EventStatusEnable(self):
        return self.ese_query

    ''' q_EventStatusRegister query function. '''           
    def q_EventStatusRegister(self):
        return self.esr_query

    ''' q_ID query function. '''        
    def q_ID(self):
        return self.idn_query

    ''' c_OperationComplete command function. '''       
    def c_OperationComplete(self):
        return self.opc_command

    ''' q_OperationComplete query function. '''     
    def q_OperationComplete(self):
        return self.opc_query

    ''' q_Options query function. '''       
    def q_Options(self):
        return self.opt_query

    ''' c_Recall command function. '''      
    def c_Recall(self, memory_location):
        if (memory_location == str(memory_location)
            or
            memory_location != int(memory_location)):
            raise TypeError ("Enter a positive whole number (int) of memory " +
                             "location from 1 to 99." +
                             " Value entered: {}. "
                             .format(memory_location) +
                             "Refer to help function for guidance of usage.")
        elif (memory_location < self.MEMORY_LOCATION_MIN
              or
              memory_location > self.MEMORY_LOCATION_MAX):
              raise ValueError ("Enter a positive whole number (int) of " +
                                "memory location from 1 to 99." +
                                " Value entered: {}. "
                                .format(memory_location) +
                                "Refer to help function for guidance of usage.")
        else:
            return self.rcl_command + str(memory_location)

    ''' c_Reset command function. '''           
    def c_Reset(self):
        return self.rst_command

    ''' c_Save command function. '''        
    def c_Save(self, memory_location):
        if (memory_location == str(memory_location)
            or
            memory_location != int(memory_location)):
            raise TypeError ("Enter a positive whole number (int) of memory " +
                             "location from 1 to 99." +
                             " Value entered: {}. "
                             .format(memory_location) +
                             "Refer to help function for guidance of usage.")
        elif (memory_location < self.MEMORY_LOCATION_MIN
              or
              memory_location > self.MEMORY_LOCATION_MAX):
              raise ValueError ("Enter a positive whole number (int) of " +
                                "memory location from 1 to 99." +
                                " Value entered: {}. "
                                .format(memory_location) +
                                "Refer to help function for guidance of usage.")
        else:
            return self.sav_command + str(memory_location)

    ''' c_ServiceRequestEnable command function. '''            
    def c_ServiceRequestEnable(self, service_request_enable_register):
        if (service_request_enable_register ==
            str(service_request_enable_register)
            or
            service_request_enable_register !=
            int(service_request_enable_register)):
            raise TypeError ("Enter a positive whole number (int) of bits " +
                             "from 0 to 255 (except 6)." +
                             " Value entered: {}. "
                             .format(service_request_enable_register) +
                             "Refer to help function for guidance of usage.")
        elif (service_request_enable_register <
              self.SERVICE_REQUEST_ENABLE_REGISTER_MIN
              or service_request_enable_register ==
              self.SERVICE_REQUEST_ENABLE_REGISTER_EXCEPT
              or service_request_enable_register >
              self.SERVICE_REQUEST_ENABLE_REGISTER_MAX):
              raise ValueError ("Enter a positive whole number (int) of bits " +
                                "from 0 to 255 (except 6)." +
                                " Value entered: {}. "
                                .format(service_request_enable_register) +
                                "Refer to help function for guidance of usage.")
        else:
            return self.sre_command + str(service_request_enable_register)

    ''' q_ServiceRequestEnable query function. '''          
    def q_ServiceRequestEnable(self):
        return self.sre_query

    ''' q_StatusByteRegister query function. '''        
    def q_StatusByteRegister(self):
        return self.stb_query

    ''' c_Trigger command function. '''     
    def c_Trigger(self):
        return self.trg_command

    ''' q_SelfTest query function. '''      
    def q_SelfTest(self):
        return self.tst_query

    ''' c_WaitToContinue command function. '''      
    def c_WaitToContinue(self):
        return self.wai_command

    ''' c_CalibrateProtect command function. '''        
    def c_CalibrateProtect(self, calibration_limit):
        if (calibration_limit == self.MIN_STRING or
            calibration_limit == self.MAX_STRING):
            return self.cal_cpr_command + calibration_limit
        else:
            raise ValueError ("Enter either MIN or MAX" +
                              " for calibration limit parameter." +
                              " Value entered: {}. "
                              .format(calibration_limit) +
                              "Refer to help function for guidance of usage.")

    ''' c_CalibrationStatus command function. '''                         
    def c_CalibrationStatus(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number " +
                             "(either 1-on or 0-off) for calibration status" +
                             " off_on parameter."
                             " Value entered: {}. "
                             .format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number " +
                              "(either 1-on or 0-off) for calibration status" +
                              " off_on parameter."
                              " Value entered: {}. "
                              .format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.cal_stat_command + str(off_on)

    ''' q_CalibrationStatus query function. '''     
    def q_CalibrationStatus(self):
        return self.cal_stat_query

    ''' c_CalibrateCurrent command function. '''    
    def c_CalibrateCurrent(self, current_calibration):
        if (current_calibration == self.MIN_STRING or
            current_calibration == self.MAX_STRING or
            current_calibration == self.ZERO_STRING):
            return self.cal_curr_command + current_calibration
        else:
            raise ValueError ("Enter either MIN, MAX or ZERO" +
                              " for current calibration parameter." +
                              " Value entered: {}. "
                              .format(current_calibration) +
                              "Refer to help function for guidance of usage.")

    ''' c_CalibrateData command function. '''                         
    def c_CalibrateData(self, num_of_lsbs):
        if (num_of_lsbs == str(num_of_lsbs) or num_of_lsbs != int(num_of_lsbs)):
            raise TypeError ("Enter a positive whole number " +
                             "(int) for least significant bits" +
                             " parameter."
                             " Value entered: {}. "
                             .format(num_of_lsbs) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.cal_data_command + str(off_on)

    ''' c_CalibrateDPOT command function. '''       
    def c_CalibrateDPOT(self, num_of_lsbs):
        if (num_of_lsbs == str(num_of_lsbs) or num_of_lsbs != int(num_of_lsbs)):
            raise TypeError ("Enter a positive whole number " +
                             "(int) for least significant bits" +
                             " parameter."
                             " Value entered: {}. "
                             .format(num_of_lsbs) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.cal_dpot_command + str(off_on)

    ''' c_CalibrateLowCurrent command function. '''     
    def c_CalibrateLowCurrent(self, low_current_calibration):
        if (low_current_calibration == self.MIN_STRING or
            low_current_calibration == self.MAX_STRING or
            low_current_calibration == self.ZERO_STRING):
            return self.cal_lcurr_command + low_current_calibration
        else:
            raise ValueError ("Enter either MIN, MAX or ZERO" +
                              " for low current calibration parameter." +
                              " Value entered: {}. "
                              .format(low_current_calibration) +
                              "Refer to help function for guidance of usage.")

    ''' c_CalibrateLowVoltage command function. '''                           
    def c_CalibrateLowVoltage(self, low_voltage_calibration):
        if (low_voltage_calibration == self.MIN_STRING or
            low_voltage_calibration == self.MAX_STRING or
            low_voltage_calibration == self.ZERO_STRING):
            return self.cal_lvolt_command + low_voltage_calibration
        else:
            raise ValueError ("Enter either MIN, MAX or ZERO" +
                              " for low voltage calibration parameter." +
                              " Value entered: {}. "
                              .format(low_voltage_calibration) +
                              "Refer to help function for guidance of usage.")

    ''' c_CalibrateSave command function. '''                             
    def c_CalibrateSave(self):
        return self.cal_save_command

    ''' c_CalibrateVoltage command function. '''        
    def c_CalibrateVoltage(self, voltage_calibration):
        if (voltage_calibration == self.MIN_STRING or
            voltage_calibration == self.MAX_STRING or
            voltage_calibration == self.ZERO_STRING):
            return self.cal_volt_command + voltage_calibration
        else:
            raise ValueError ("Enter either MIN, MAX or ZERO" +
                              " for voltage calibration parameter." +
                              " Value entered: {}. "
                              .format(voltage_calibration) +
                              "Refer to help function for guidance of usage.")

    ''' c_CalibrateVoltageProtect command function. '''                           
    def c_CalibrateVoltageProtect(self, voltage_calibration_limit):
        if (voltage_calibration_limit == self.MIN_STRING or
            voltage_calibration_limit == self.MAX_STRING):
            return self.cal_vpr_command + voltage_calibration_limit
        else:
            raise ValueError ("Enter either MIN or MAX" +
                              " for voltage calibration limit parameter." +
                              " Value entered: {}. "
                              .format(voltage_calibration_limit) +
                              "Refer to help function for guidance of usage.")

    ''' c_CalibrateZero command function. '''                             
    def c_CalibrateZero(self):
        return self.cal_zero_command

    ''' c_EnableSingleTrigger command function. '''     
    def c_EnableSingleTrigger(self):
        return self.init_imm_command

    ''' c_EDContinuousTriggers command function. '''        
    def c_EDContinuousTriggers(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number " +
                             "(either 1-on or 0-off) for continuous triggers" +
                             " off_on parameter."
                             " Value entered: {}. "
                             .format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number " +
                              "(either 1-on or 0-off) for continuous triggers" +
                              " off_on parameter."
                              " Value entered: {}. "
                              .format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.init_cont_command + str(off_on)

    ''' q_EDContinuousTriggers query function. '''          
    def q_EDContinuousTriggers(self):
        return self.init_cont_query

    ''' q_MeasureCurrent query function. '''        
    def q_MeasureCurrent(self):
        return self.meas_curr_query

    ''' q_MeasureVoltage query function. '''        
    def q_MeasureVoltage(self):
        return self.meas_volt_query

    ''' c_EDOutput command function. '''        
    def c_EDOutput(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number " +
                             "(either 1-on or 0-off) for power supplier" +
                             " output off_on parameter."
                             " Value entered: {}. "
                             .format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number " +
                              "(either 1-on or 0-off) for power supplier" +
                              " output off_on parameter."
                              " Value entered: {}. "
                              .format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.outp_command + str(off_on)

    ''' q_EDOutput query function. '''          
    def q_EDOutput(self):
            return self.outp_query

    ''' c_OperatingMode command function. '''           
    def c_OperatingMode(self, mode):
        if (mode == self.VOLT_STRING or mode == self.CURR_STRING):
            return self.func_mode_command + mode
        else:
            raise ValueError ("Enter either VOLT (voltage) or CURR (current)" +
                              " for operating mode parameter." +
                              " Value entered: {}. "
                              .format(mode) +
                              "Refer to help function for guidance of usage.")

    ''' q_OperatingMode query function. '''                           
    def q_OperatingMode(self):
            return self.func_mode_query

    ''' c_OperatingModeTrigger command function. '''            
    def c_OperatingModeTrigger(self, mode):
        if (mode == self.VOLT_STRING or mode == self.CURR_STRING):
            return self.func_mode_trigger_command + mode
        else:
            raise ValueError ("Enter either VOLT (voltage) or CURR (current)" +
                              " for operating mode parameter." +
                              " Value entered: {}. "
                              .format(mode) +
                              "Refer to help function for guidance of usage.")

    ''' q_OperatingModeTrigger query function. '''                            
    def q_OperatingModeTrigger(self):
            return self.func_mode_trigger_query

    ''' c_ClearAllListEntries command function. '''         
    def c_ClearAllListEntries(self):
        return self.list_cle_command

    ''' c_ListCountExecution command function. '''      
    def c_ListCountExecution(self, times_to_execute):
        if (times_to_execute == str(times_to_execute)
            or
            times_to_execute != int(times_to_execute)):
            raise TypeError ("Enter a whole positive number (int) from 0 to" +
                             " 255 for list's times to execute parameter." +
                             " Value entered: {}. "
                             .format(times_to_execute) +
                             "Refer to help function for guidance of usage.")
        elif(times_to_execute < self.TIMES_TO_EXEC_MIN
            or times_to_execute > self.TIMES_TO_EXEC_MAX):
            raise ValueError ("Enter a whole positive number (int) from 0 to" +
                              " 255 for list's times to execute parameter." +
                              " Value entered: {}. "
                              .format(times_to_execute) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.list_coun_command + str(times_to_execute)

    ''' q_ListCountExecution query function. '''            
    def q_ListCountExecution(self):
            return self.list_coun_query

    ''' c_ListCountSkip command function. '''                   
    def c_ListCountSkip(self, num_of_skip_steps):
        if (num_of_skip_steps == str(num_of_skip_steps)
            or
            num_of_skip_steps != int(num_of_skip_steps)):
            raise TypeError ("Enter a whole positive number (int) from 0 to" +
                             " 255 for list's skip steps parameter." +
                             " Value entered: {}. "
                             .format(num_of_skip_steps) +
                             "Refer to help function for guidance of usage.")
        elif(num_of_skip_steps < self.SKIP_STEPS_MIN
            or num_of_skip_steps > self.SKIP_STEPS_MAX):
            raise ValueError ("Enter a whole positive number (int) from 0 to" +
                              " 255 for list's skip steps parameter." +
                              " Value entered: {}. "
                              .format(num_of_skip_steps) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.list_coun_skip_command + str(num_of_skip_steps)

    ''' q_ListCountSkip query function. '''         
    def q_ListCountSkip(self):
            return self.list_coun_skip_query

    ''' c_AddCurrentToList command function. '''            
    def c_AddCurrentToList(self, current_value):
        if (current_value != str(current_value)):
            raise TypeError ("Enter digits with decimal point and Exponent," +
                              " e.g. 2.71E1 for 27.1." +
                              " Current value entered: {}. "
                              .format(current_value) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.list_curr_command + current_value

    ''' q_FindCurrentEntriesInList query function. '''          
    def q_FindCurrentEntriesInList(self):
            return self.list_curr_query

    ''' q_CurrentNumOfPointsInList query function. '''          
    def q_CurrentNumOfPointsInList(self):
            return self.list_curr_poin_query

    ''' c_ListDirectionExecution command function. '''          
    def c_ListDirectionExecution(self, list_direction):
        if (list_direction == self.UP_STRING
            or list_direction == self.DOWN_STRING):
            return self.list_dir_command + list_direction
        else:
            raise ValueError ("Enter either UP or DOWN" +
                              " for list direction parameter." +
                              " Value entered: {}. "
                              .format(list_direction) +
                              "Refer to help function for guidance of usage.")

    ''' q_ListDirectionExecution query function. '''                              
    def q_ListDirectionExecution(self):
            return self.list_dir_query

    ''' c_KeepDwelActiveFor command function. '''           
    def c_KeepDwelActiveFor(self, active_for):
        if (active_for == str(active_for)):
            raise TypeError ("Enter a positive number (int or float) of" +
                             " seconds from 0.0005 to 10 for Dwel active" +
                             " for parameter." +
                             " Value entered: {}. "
                             .format(active_for) +
                             "Refer to help function for guidance of usage.")
        elif (active_for < self.ACTIVE_FOR_MIN
              or active_for > self.ACTIVE_FOR_MAX):
              raise ValueError ("Enter a positive number (int or float) of" +
                              " seconds from 0.0005 to 10 for Dwel active" +
                              " for parameter." +
                              " Value entered: {}. "
                              .format(active_for) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.list_dwel_command + str(active_for)

    ''' q_ListDwelTimes query function. '''         
    def q_ListDwelTimes(self):
            return self.list_dwel_query

    ''' q_DwelTimesNumOfPointsInList query function. '''            
    def q_DwelTimesNumOfPointsInList(self):
            return self.list_dwel_poin_query

    ''' c_ListOrderExecution command function. '''          
    def c_ListOrderExecution(self, list_order):
        if (list_order == self.SEQ_STRING
            or list_order == self.DSEQ_STRING):
            return self.list_gen_command + list_order
        else:
            raise ValueError ("Enter either SEQ or DSEQ" +
                              " for list order parameter." +
                              " Value entered: {}. "
                              .format(list_order) +
                              "Refer to help function for guidance of usage.")

    ''' q_ListOrderExecution query function. '''                              
    def q_ListOrderExecution(self):
            return self.list_gen_query

    ''' c_ListLocationToBeQueried command function. '''         
    def c_ListLocationToBeQueried(self, location_to_be_queried):
        if (location_to_be_queried == str(location_to_be_queried)
            or location_to_be_queried != int(location_to_be_queried)):
            raise TypeError ("Enter a whole positive number (int) from 0 to" +
                             " 1001 for location to be queried parameter." +
                             " Value entered: {}. "
                             .format(location_to_be_queried) +
                             "Refer to help function for guidance of usage.")
        elif (location_to_be_queried < self.LOCATION_TO_BE_QUERIED_MIN
              or location_to_be_queried > self.LOCATION_TO_BE_QUERIED_MAX):
              raise TypeError ("Enter a whole positive number (int) from 0 to" +
                             " 1001 for location_to_be_queried parameter." +
                             " Value entered: {}. "
                             .format(location_to_be_queried) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.list_quer_command + str(location_to_be_queried)

    ''' q_ListLocationToBeQueried query function. '''           
    def q_ListLocationToBeQueried(self):
            return self.list_quer_query

    ''' c_DwellTimeResolution command function. '''         
    def c_DwellTimeResolution(self, time_resolution):
        if (time_resolution == self.SLOW_STRING
            or time_resolution == self.FAST_STRING):
            return self.list_mode_command + time_resolution
        else:
            raise ValueError ("Enter either SLOW or FAST" +
                              " for Dwell time resolution parameter." +
                              " Value entered: {}. "
                              .format(time_resolution) +
                              "Refer to help function for guidance of usage.")

    ''' q_DwellTimeResolution query function. '''                             
    def q_DwellTimeResolution(self):
            return self.list_mode_query

    ''' c_ExecutionOrderForListDataPoints command function. '''         
    def c_ExecutionOrderForListDataPoints(self, data_point):
        if (data_point == str(data_point) or data_point != int(data_point)):
            raise TypeError ("Enter a whole positive number (int) from 0 to" +
                             " 511 for data point parameter." +
                             " Value entered: {}. "
                             .format(data_point) +
                             "Refer to help function for guidance of usage.")
        elif (data_point < 0 or data_point > 511):
            raise ValueError ("Enter a whole positive number (int) from 0 to" +
                              " 511 for data point parameter." +
                              " Value entered: {}. "
                              .format(data_point) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.list_seq_command + str(data_point)

    ''' q_ExecutionOrderForListDataPoints query function. '''           
    def q_ExecutionOrderForListDataPoints(self):
            return self.list_seq_query

    ''' c_AddVoltageToList command function. '''            
    def c_AddVoltageToList(self, voltage_value):
        if (voltage_value != str(voltage_value)):
            raise TypeError ("Enter digits with decimal point and Exponent," +
                             " e.g. 2.71E1 for 27.1." +
                             " Voltage value entered: {}. "
                             .format(voltage_value) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.list_volt_command + voltage_value

    ''' q_FindVoltageEntriesInList query function. '''          
    def q_FindVoltageEntriesInList(self):
            return self.list_volt_query

    ''' q_VoltageNumOfPointsInList query function. '''          
    def q_VoltageNumOfPointsInList(self):
            return self.list_volt_poin_query

    ''' c_SetCurrentLevel command function. '''         
    def c_SetCurrentLevel(self, current_value):
        if (current_value != str(current_value)):
            raise TypeError ("Enter digits with decimal point and Exponent," +
                             " e.g. 2.71E1 for 27.1." +
                             " Current value entered: {}. "
                             .format(current_value) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.curr_command + str(current_value)

    ''' q_FindCurrentLevel query function. '''          
    def q_FindCurrentLevel(self):
            return self.curr_query

    ''' c_SetCurrentMode command function. '''          
    def c_SetCurrentMode(self, current_mode):
        if (current_mode == self.LIST_STRING
            or current_mode == self.FIX_STRING):
            return self.curr_mode_command + current_mode
        else:
            raise ValueError ("Enter either LIST or FIX" +
                              " for current mode parameter." +
                              " Value entered: {}. "
                              .format(current_mode) +
                              "Refer to help function for guidance of usage.")

    ''' c_SetCurrentModeToTran command function. '''                              
    def c_SetCurrentModeToTran(self, current_mode, tran_seconds):
        if (tran_seconds != int(tran_seconds)):
            raise TypeError ("Enter a positive whole (int) transient seconds" +
                             " up to 10." +
                             " Value entered: {}. "
                             .format(tran_seconds) +
                             "Refer to help function for guidance of usage.")
        elif (tran_seconds < self.TRAN_SECONDS_MIN
              or tran_seconds > self.TRAN_SECONDS_MAX):
              raise ValueError ("Enter a positive whole (int) transient" +
                              " seconds up to 10." +
                              " Value entered: {}. "
                              .format(tran_seconds) +
                              "Refer to help function for guidance of usage.")
        else:
            if (current_mode == self.TRAN_STRING):
                return self.curr_mode_command + current_mode + \
                       self.data_separator + str(tran_seconds)
            else:
                raise ValueError ("Enter TRAN current mode." +
                                " Value entered: {}. "
                                .format(current_mode) +
                                "Refer to help function for guidance of usage.")

    ''' q_FindCurrentMode query function. '''                               
    def q_FindCurrentMode(self):
            return self.curr_mode_query

    ''' c_SetCurrentRange command function. '''         
    def c_SetCurrentRange(self, current_range):
        if (current_range == str(current_range)
            or current_range != int(current_range)):
            raise TypeError ("Enter a positive whole number (1-full scale or" +
                             " 4-1/4 scale) for current range parameter." +
                             " Value entered: {}. "
                             .format(current_range) +
                             "Refer to help function for guidance of usage.")
        else:
            if (current_range == self.RANGE_FULL_SCALE
                or current_range == self.RANGE_QUARTER_SCALE):
                return self.curr_rang_command + str(current_range)
            else:
                raise ValueError ("Enter a positive whole number (1-full" +
                              " scale or 4-1/4 scale) for current range" +
                              " parameter." +
                              " Value entered: {}. "
                              .format(current_range) +
                              "Refer to help function for guidance of usage.")

    ''' q_FindCurrentRange query function. '''                            
    def q_FindCurrentRange(self):
            return self.curr_rang_query

    ''' c_SetAutoCurrentRange command function. '''         
    def c_SetAutoCurrentRange(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a whole positive number (either 1-on or"+
                             " 0-off) for current auto range off_on parameter."+
                             " Value entered: {}. "
                             .format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a whole positive number (either 1-on or"+
                              " 0-off) for current auto range off_on parameter."
                              +" Value entered: {}. "
                              .format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.curr_rang_auto_command + str(off_on)

    ''' c_SetCurrentTriggerValue command function. '''          
    def c_SetCurrentTriggerValue(self, current_value):
        if (current_value != str(current_value)):
            raise TypeError ("Enter digits with decimal point and Exponent," +
                             " e.g. 2.71E1 for 27.1." +
                             " Current value entered: {}. "
                             .format(current_value) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.curr_trig_command + current_value

    ''' q_FindCurrentTriggerValue query function. '''           
    def q_FindCurrentTriggerValue(self):
            return self.curr_trig_query

    ''' c_SetVoltageLevel command function. '''         
    def c_SetVoltageLevel(self, voltage_value):
        if (voltage_value != str(voltage_value)):
            raise TypeError ("Enter digits with decimal point and Exponent," +
                             " e.g. 2.71E1 for 27.1." +
                             " Voltage value entered: {}. "
                             .format(voltage_value) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.volt_command + voltage_value

    ''' q_FindVoltageLevel query function. '''          
    def q_FindVoltageLevel(self):
            return self.volt_query

    ''' c_SetVoltageMode command function. '''          
    def c_SetVoltageMode(self, voltage_mode):
        if (volta_mode == self.LIST_STRING
            or volta_mode == self.FIX_STRING):
             return self.volt_mode_command + volta_mode
        else:
            raise ValueError ("Enter either LIST or FIX" +
                              " for voltage mode parameter." +
                              " Value entered: {}. "
                              .format(voltage_mode) +
                              "Refer to help function for guidance of usage.")

    ''' c_SetVoltageModeToTran command function. '''                              
    def c_SetVoltageModeToTran(self, voltage_mode, tran_seconds):
        if (tran_seconds != int(tran_seconds)):
            raise TypeError ("Enter a positive whole (int) transient seconds" +
                             " up to 10." +
                             " Value entered: {}. "
                             .format(tran_seconds) +
                             "Refer to help function for guidance of usage.")
        elif (tran_seconds < self.TRAN_SECONDS_MIN
              or tran_seconds > self.TRAN_SECONDS_MAX):
              raise ValueError ("Enter a positive whole (int) transient" +
                              " seconds up to 10." +
                              " Value entered: {}. "
                              .format(tran_seconds) +
                              "Refer to help function for guidance of usage.")
        else:
            if (voltage_mode == self.TRAN_STRING):
                return self.volt_mode_command + voltage_mode + \
                       self.data_separator + str(tran_seconds)
            else:
                raise ValueError ("Enter TRAN voltage mode." +
                                " Value entered: {}. "
                                .format(voltage_mode) +
                                "Refer to help function for guidance of usage.")
                                
    ''' q_FindVoltageMode query function. '''   
    def q_FindVoltageMode(self):
            return self.volt_mode_query

    ''' c_SetVoltageRange command function. '''         
    def c_SetVoltageRange(self, voltage_range):
        if (voltage_range == str(voltage_range)
            or voltage_range != int(voltage_range)):
            raise TypeError ("Enter a positive whole number (1-full scale or" +
                             " 4-1/4 scale) for voltage range parameter." +
                             " Value entered: {}. "
                             .format(voltage_range) +
                             "Refer to help function for guidance of usage.")
        else:
            if (current_range == self.RANGE_FULL_SCALE
                or current_range == self.RANGE_QUARTER_SCALE):
                return self.volt_rang_command + str(voltage_range)
            else:
                raise ValueError ("Enter a positive whole number (1-full" +
                                  " scale or 4-1/4 scale) for voltage range" +
                                  " parameter." +
                                  " Value entered: {}. "
                                  .format(voltage_range) +
                                  "Refer to help function for guidance " +
                                  "of usage.")

    ''' q_FindVoltageRange query function. '''                                
    def q_FindVoltageRange(self):
            return self.volt_rang_query

    ''' c_SetAutoVoltageRange command function. '''         
    def c_SetAutoVoltageRange(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a whole positive number (either 1-on or"+
                             " 0-off) for voltage auto range off_on parameter."+
                             " Value entered: {}. "
                             .format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a whole positive number (either 1-on or"+
                              " 0-off) for voltage auto range off_on" +
                              " parameter." +
                              " Value entered: {}. "
                              .format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.volt_rang_auto_command + str(off_on)

    ''' c_SetVoltageTriggerValue command function. '''          
    def c_SetVoltageTriggerValue(self, voltage_value):
        if (voltage_value != str(voltage_value)):
            raise TypeError ("Enter digits with decimal point and Exponent," +
                             " e.g. 2.71E1 for 27.1." +
                             " Voltage value entered: {}. "
                             .format(voltage_value) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.volt_trig_command + voltage_value

    ''' q_FindVoltageTriggerValue query function. '''           
    def q_FindVoltageTriggerValue(self):
            return self.volt_trig_query

    ''' q_FindOperationConditionRegisterValue query function. '''           
    def q_FindOperationConditionRegisterValue(self):
            return self.stat_oper_cond_query

    ''' c_SetOperationEnableRegister command function. '''          
    def c_SetOperationEnableRegister(self, register_bits):
        if (register_bits == str(register_bits)
            or register_bits != int(register_bits)):
            raise TypeError ("Enter a whole positive number (from 0-1313"+
                             ") for register bits parameter."+
                             " Value entered: {}. "
                             .format(register_bits) +
                             "Refer to help function for guidance of usage.")
        elif (register_bits > self.REGISTER_BITS_MAX
              or register_bits < self.REGISTER_BITS_MIN):
            raise ValueError ("Enter a whole positive number (from 0-1313"+
                              ") for register bits parameter."+
                              " Value entered: {}. "
                              .format(register_bits) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.stat_oper_enab_command + str(register_bits)

    ''' q_FindOperationEnableRegister query function. '''           
    def q_FindOperationEnableRegister(self):
        return self.stat_oper_enab_query

    ''' q_FindChangesByOperationEnableRegister query function. '''      
    def q_FindChangesByOperationEnableRegister(self):
        return self.stat_oper_query

    ''' c_DisableReportingOfStatusEvents command function. '''      
    def c_DisableReportingOfStatusEvents(self):
        return self.stat_pres_command

    ''' q_FindLatchConditionOfQuestionableEventRegister query function. '''     
    def q_FindLatchConditionOfQuestionableEventRegister(self):
        return self.stat_ques_query

    ''' q_FindQuestionableConditionRegisterValue query function. '''        
    def q_FindQuestionableConditionRegisterValue(self):
        return self.stat_ques_cond_query

    ''' c_SetQuestionableConditionEnableRegister command function. '''      
    def c_SetQuestionableConditionEnableRegister(self, register_value):
        if (register_value == str(register_value)
            or register_value != int(register_value)):
            raise TypeError ("Enter a whole positive number (int) for register"+
                             " bits parameter."+
                             " Value entered: {}. "
                             .format(register_value) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.stat_ques_enab_command + str(register_value)

    ''' q_FindQuestionableConditionEnableRegister query function. '''           
    def q_FindQuestionableConditionEnableRegister(self):
        return self.stat_ques_enab_query

    ''' c_EmitBriefAudibleTone command function. '''        
    def c_EmitBriefAudibleTone(self):
        return self.syst_beep_command

    ''' c_EDEchoMode command function. '''      
    def c_EDEchoMode(self, off_on):
        if (off_on == self.ON_STRING
            or off_on == self.OFF_STRING):
            return self.syst_comm_ser_echo_command + off_on
        else:
            raise ValueError ("Enter either ON or OFF" +
                              " for echo mode off_on parameter." +
                              " Value entered: {}. "
                              .format(off_on) +
                              "Refer to help function for guidance of usage.")

    ''' q_EDEchoMode query function. '''                              
    def q_EDEchoMode(self):
        return self.syst_comm_ser_echo_query

    ''' c_EDDataFlowControl command function. '''       
    def c_EDDataFlowControl(self, none_xon):
        if (none_xon == self.XON_STRING
            or none_xon == self.NONE_STRING):
            return self.syst_comm_ser_pace_command + none_xon
        else:
            raise ValueError ("Enter either XON or NONE" +
                              " for data flow control none_xon parameter." +
                              " Value entered: {}. "
                              .format(none_xon) +
                              "Refer to help function for guidance of usage.")
                              
    ''' q_EDDataFlowControl query function. ''' 
    def q_EDDataFlowControl(self):
        return self.syst_comm_ser_pace_query

    ''' q_PostErrorMessages query function. '''     
    def q_PostErrorMessages(self):
        return self.syst_err_query

    ''' q_PostErrorCode query function. '''     
    def q_PostErrorCode(self):
        return self.syst_err_code_query

    ''' q_PostAllErrorCodes query function. '''     
    def q_PostAllErrorCodes(self):
        return self.syst_err_code_all_query

    ''' c_SetPasswordEnableState command function. '''      
    def c_SetPasswordEnableState(self, value):
        return self.syst_pass_cen_command + value

    ''' c_ClearPasswordEnableState command function. '''        
    def c_ClearPasswordEnableState(self, value):
        return self.syst_pass_cdis_command + value

    ''' c_SetNewPassword command function. '''      
    def c_SetNewPassword(self, old_password, new_password):
        return self.syst_pass_new_command + old_password + \
               self.comma + new_password

    ''' q_FindPasswordState query function. '''            
    def q_FindPasswordState(self):
        return self.syst_pass_stat_query

    ''' c_SetRemoteCommunication command function. '''      
    def c_SetRemoteCommunication(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a whole positive number (either 1-on or"+
                             " 0-off) for remote comm. off_on parameter."+
                             " Value entered: {}. "
                             .format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a whole positive number (either 1-on or"+
                              " 0-off) for remote comm. off_on" +
                              " parameter." +
                              " Value entered: {}. "
                              .format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.syst_rem_command + str(off_on)

    ''' q_FindCommunicationMode query function. '''     
    def q_FindCommunicationMode(self):
        return self.syst_rem_query

    ''' c_InitNVRAMVariablesToFactoryDefaults command function. '''     
    def c_InitNVRAMVariablesToFactoryDefaults(self):
        return self.syst_sec_imm_command

    ''' c_SetSystemFunctions command function. '''      
    def c_SetSystemFunctions(self, set_value):
        if (set_value == self.CM0_STRING or set_value == self.CM1_STRING
            or set_value == self.DC0_STRING or set_value == self.DC1_STRING
            or set_value == self.LF0_STRING or set_value == self.LF1_STRING
            or set_value == self.RO0_STRING or set_value == self.RO1_STRING):
            return self.syst_set_command + set_value
        else:
            raise ValueError ("Enter either CM0, CM1, DC0, DC1," +
                              " LF0, LF1, RO0 or RO1 set value." +
                              " Value entered: {}. "
                              .format(set_value) +
                              " Refer to help function for guidance of usage.")

    ''' q_FindSetSystemFunctions query function. '''                              
    def q_FindSetSystemFunctions(self):
        return self.syst_set_query

    ''' q_FindImplementedSCPIVersion command function. '''      
    def q_FindImplementedSCPIVersion(self):
        return self.syst_vers_query

    ''' sendMultipleKepcoSCPI queries/commands function. '''        
    def sendMultipleKepcoSCPI(self, *args):
        if (len(args) <= self.MIN_SCPI_MSGS):
            raise Exception ("Enter at least 2 SCPI messages" +
                             " (commands/queries) in string ('') format." +
                             " Value entered: {}. ".format(args) +
                             "Refer to help function for guidance of usage.")
        else:
            split_string = self.message_unit_separator + self.root_specifier
            return split_string.join(args)

    ''' testKepcoSCPI queries/commands function. '''        
    def testKepcoSCPI(self, command):
        if (command != str(command)):
            raise TypeError ("Enter command/query to test in string ('') " +
                             "format." +
                             " Value entered: {}. ".format(command) +
                             "Refer to help function for guidance of usage.")
        else:
            return command
