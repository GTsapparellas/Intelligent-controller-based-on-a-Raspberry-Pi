# Put comments

# Gaussmeter class for Intelligent Controller project purposes.
# @author: Giorgos Tsapparellas
# @date: 30 June 2019

class LakeShore425_Gauss:

    def __init__(self):
        # Message Terminator
        #self.messageTerminator = "\n"
        # Comma Seperator
        self.comma = ","

        self.newline = "\n"

        self.process_last_received_query = "?"
        self.idn_query = "*IDN?"
        self.rst_command = "*RST"
        self.alarm_command = "ALARM "
        self.alarm_query = "ALARM?"
        self.alarmst_query = "ALARMST?"
        self.auto_command = "AUTO "
        self.auto_query = "AUTO?"
        self.beep_command = "BEEP "
        self.beep_query = "BEEP?"
        self.brigt_command = "BRIGT "
        self.brigt_query = "BRIGT?"
        self.dflt_command = "DFLT 99"
        self.keyst_query = "KEYST?"
        self.lock_command = "LOCK "
        self.lock_query = "LOCK?"
        self.mxhold_command = "MXHOLD "
        self.mxhold_query = "MXHOLD?"
        self.mxrst_command = "MXRST"
        self.opst_query = "OPST?"
        self.prbfcomp_command = "PRBFCOMP "
        self.prbfcomp_query = "PRBFCOMP?"
        self.prbsens_query = "PRBSENS?"
        self.prbsnum_query = "PRBSNUM?"
        self.range_command = "RANGE "
        self.range_query = "RANGE?"
        self.rdgfield_query = "RDGFIELD?"
        self.rdgmode_command = "RDGMODE "
        self.rdgmode_query = "RDGMODE?"
        self.rdgmnmx_query = "RDGMNMX?"
        self.rdgmx_query = "RDGMX?"
        self.rdgrel_query = "RDGREL?"
        self.rel_command = "REL "
        self.rel_query = "REL?"
        self.relay_command = "RELAY "
        self.relay_query = "RELAY?"
        self.relayst_query = "RELAYST?"
        self.relsp_command = "RELSP "
        self.relsp_query = "RELSP?"
        self.type_query = "TYPE?"
        self.unit_command = "UNIT "
        self.unit_query = "UNIT?"
        self.zclear_command = "ZCLEAR"
        self.zprobe_command = "ZPROBE"

        # Parameters values
        self.OFF = 0
        self.ON = 1

        self.MAGNITUDE_CHECK = 1
        self.ALGEBRAIC_CHECK = 2

        self.TRIGGER_OUTSIDE = 1
        self.TRIGGER_INSIDE = 2

        self.DISPLAY_CONTRAST_MIN = 1
        self.DISPLAY_CONTRAST_MAX = 32

        self.UNLOCKED = 0
        self.LOCKED = 1

        self.FIELD_RANGE_MIN = 1
        self.FIELD_RANGE_MAX = 4

        self.DC_MODE = 1
        self.RMS_MODE = 2

        self.WIDE_BAND = 1
        self.NARROW_BAND = 2

        self.MODE_MIN = 0
        self.MODE_MAX = 2

        self.ALARM_TYPE_MIN = 1
        self.ALARM_TYPE_MAX = 3

        self.UNITS_MIN = 1
        self.UNITS_MAX = 4

        self.Exit = 0
        self.query_ProcessLastQueryReceived = 1
        self.query_ID = 2
        self.command_Reset = 3
        self.command_InputAlarmParameter = 4
        self.query_InputAlarmParameter = 5
        self.query_AlarmStatus = 6
        self.command_AutoRange = 7
        self.query_AutoRange = 8
        self.command_AlarmAudible = 9
        self.query_AlarmAudible = 10
        self.command_DisplayContrast = 11
        self.query_DisplayContrast = 12
        self.command_FactoryDefaults = 13
        self.query_KeypadStatus = 14
        self.command_FrontPanelKeypadLock = 15
        self.query_FrontPanelKeypadLock = 16
        self.command_MaxHold = 17
        self.query_MaxHold = 18
        self.command_MaxHoldReset = 19
        self.query_OperationalStatus = 20
        self.command_ProbeFieldCompensation = 21
        self.query_ProbeFieldCompensation = 22
        self.query_ProbeSensitivity = 23
        self.query_ProbeSerialNumber = 24
        self.command_FieldRange = 25
        self.query_FieldRange = 26
        self.query_FieldReading = 27
        self.command_MeasurementMode = 28
        self.query_MeasurementMode = 29
        self.query_MaxMinReading = 30
        self.query_MaxReading = 31
        self.query_RelativeReading = 32
        self.command_RelativeMode = 33
        self.query_RelativeMode = 34
        self.command_RelayControlParameter = 35
        self.query_RelayControlParameter = 36
        self.query_RelayStatus = 37
        self.command_RelativeSetpoint = 38
        self.query_RelativeSetpoint = 39
        self.query_ProbeType = 40
        self.command_FieldUnits = 41
        self.query_FieldUnits = 42
        self.command_ClearZeroProbe = 43
        self.query_ZeroProbe = 44
        self.c_testGaussCommand = 45
        self.q_testGaussQuery = 46

    def q_ProcessLastQueryReceived(self):
        return self.process_last_received_query

    def q_ID(self):
        return self.idn_query

    def c_Reset(self):
        return self.rst_command

    def c_InputAlarmParameter(self, off_on, mode, low_value, high_value,
                              out_in, alarm_sort, audible):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-on or 0-off) for alarm off_on parameter." +
                             " Value entered: {}. ".format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-on or 0-off) for alarm off_on parameter." +
                              " Value entered: {}. ".format(off_on) +
                              "Refer to help function for guidance of usage.")
        elif (mode == str(mode) or mode != int(mode)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-magnitude check or 2-algebraic check)" +
                             " for alarm mode parameter." +
                             " Value entered: {}. ".format(mode) +
                             "Refer to help function for guidance of usage.")
        elif (mode > self.ALGEBRAIC_CHECK or mode < self.MAGNITUDE_CHECK):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-magnitude check or 2-algebraic check) for" +
                              " alarm mode parameter." +
                              " Value entered: {}. ".format(mode) +
                              "Refer to help function for guidance of usage.")
        elif (low_value == str(low_value) or low_value != int(low_value)):
            raise TypeError ("Enter a positive whole number for alarm" +
                             " low_value parameter." +
                             " Value entered: {}. ".format(low_value) +
                             "Refer to help function for guidance of usage.")
        elif (high_value == str(high_value) or high_value != int(high_value)):
            raise TypeError ("Enter a positive whole number for alarm" +
                             " high_value parameter." +
                             " Value entered: {}. ".format(high_value) +
                             "Refer to help function for guidance of usage.")
        elif (out_in == str(out_in) or out_in != int(out_in)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-trigger on outside of setpoints or 2-trigger" +
                             " on inside of setpoints) for alarm" +
                             " out_in parameter." +
                             " Value entered: {}. ".format(out_in) +
                             "Refer to help function for guidance of usage.")
        elif (out_in > self.TRIGGER_INSIDE or out_in < self.TRIGGER_OUTSIDE):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-trigger on outside of setpoints or 2-trigger"+
                              " on inside of setpoints) for alarm" +
                              " out_in parameter." +
                              " Value entered: {}. ".format(out_in) +
                              "Refer to help function for guidance of usage.")
        elif (alarm_sort == str(alarm_sort) or alarm_sort != int(alarm_sort)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-on or 0-off) for alarm sort parameter." +
                             " Value entered: {}. ".format(alarm_sort) +
                             "Refer to help function for guidance of usage.")
        elif (alarm_sort > self.ON or alarm_sort < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-on or 0-off) for alarm sort parameter." +
                              " Value entered: {}. ".format(alarm_sort) +
                              "Refer to help function for guidance of usage.")
        elif (audible == str(audible) or audible != int(audible)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-on or 0-off) for alarm audible parameter." +
                             " Value entered: {}. ".format(audible) +
                             "Refer to help function for guidance of usage.")
        elif (audible > self.ON or audible < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-on or 0-off) for alarm audible parameter." +
                              " Value entered: {}. ".format(audible) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.alarm_command + str(off_on) + self.comma + str(mode) + \
                   self.comma + str(low_value) + self.comma + \
                   str(high_value) + self.comma + str(out_in) + self.comma + \
                   str(alarm_sort) + self.comma + str(audible)

    def q_InputAlarmParameter(self):
        return self.alarm_query

    def q_AlarmStatus(self):
        return self.alarmst_query

    def c_AutoRange(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-on or 0-off) for auto range off_on parameter."+
                             " Value entered: {}. ".format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-on or 0-off) for auto range" +
                              " off_on parameter." +
                              " Value entered: {}. ".format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.auto_command + str(off_on)

    def q_AutoRange(self):
        return self.auto_query

    def c_AlarmAudible(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-on or 0-off) for alarm audible" +
                             " off_on parameter." +
                             " Value entered: {}. ".format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-on or 0-off) for alarm audible" +
                              " off_on parameter."+
                              " Value entered: {}. ".format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.beep_command + str(off_on)

    def q_AlarmAudible(self):
        return self.beep_query

    def c_DisplayContrast(self, display_contrast):
        if (display_contrast == str(display_contrast) or
            display_contrast != int(display_contrast)):
            raise TypeError ("Enter a positive whole number (1-32) for" +
                             " display contrast parameter." +
                             " Value entered: {}. ".format(display_contrast) +
                             "Refer to help function for guidance of usage.")
        elif (display_contrast > self.DISPLAY_CONTRAST_MAX or
              display_contrast < self.DISPLAY_CONTRAST_MIN):
            raise ValueError ("Enter a positive whole number (1-32) for" +
                              " display contrast parameter." +
                              " Value entered: {}. ".format(display_contrast) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.brigt_command + str(display_contrast)

    def q_DisplayContrast(self):
        return self.brigt_query

    def c_FactoryDefaults(self):
        return self.dflt_command

    def q_KeypadStatus(self):
        return self.keyst_query

    def c_FrontPanelKeypadLock(self, state):
        if (state == str(state) or state != int(state)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 0-unlocked or 1-locked) for front panel" +
                             " keypad state parameter." +
                             " Value entered: {}. ".format(state) +
                             "Refer to help function for guidance of usage.")
        elif (state > self.LOCKED or state < self.UNLOCKED):
            raise ValueError ("Enter a positive whole number (either" +
                              " 0-unlocked or 1-locked) for front panel" +
                              " keypad state parameter." +
                              " Value entered: {}. ".format(state) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.lock_command + str(state)

    def q_FrontPanelKeypadLock(self):
        return self.lock_query

    def c_MaxHold(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 0-off or 1-on) for maximum hold" +
                             " off_on parameter." +
                             " Value entered: {}. ".format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 0-off or 1-on) for maximum hold" +
                              " off_on parameter." +
                              " Value entered: {}. ".format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.mxhold_command + str(off_on)

    def q_MaxHold(self):
        return self.mxhold_query

    def c_MaxHoldReset(self):
        return self.mxrst_command

    def q_OperationalStatus(self):
        return self.opst_query

    def c_ProbeFieldCompensation(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 0-off or 1-on) for probe field compensation" +
                             " off_on parameter." +
                             " Value entered: {}. ".format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 0-off or 1-on) for probe field compensation" +
                              " off_on parameter." +
                              " Value entered: {}. ".format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.prbfcomp_command + str(off_on)

    def q_ProbeFieldCompensation(self):
        return self.prbfcomp_query

    def q_ProbeSensitivity(self):
        return self.prbsens_query

    def q_ProbeSerialNumber(self):
        return self.prbsnum_query

    def c_FieldRange(self, field_range):
        if (field_range == str(field_range) or field_range != int(field_range)):
            raise TypeError ("Enter a positive whole number (1-4) for" +
                             " field range parameter." +
                             " Value entered: {}. ".format(field_range) +
                             "Refer to help function for guidance of usage.")
        elif (field_range > self.FIELD_RANGE_MAX or
              field_range < self.FIELD_RANGE_MIN):
            raise ValueError ("Enter a positive whole number (1-4) for" +
                              " field range parameter." +
                              " Value entered: {}. ".format(field_range) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.range_command + str(field_range)

    def q_FieldRange(self):
        return self.range_query

    def q_FieldReading(self):
        return self.rdgfield_query

    def c_MeasurementMode(self, mode, dc_filter, band):
        if (mode == str(mode) or mode != int(mode)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-DC mode or 2-RMS mode) for" +
                             " measurement mode parameter." +
                             " Value entered: {}. ".format(mode) +
                             "Refer to help function for guidance of usage.")
        elif (mode > self.RMS_MODE or mode < self.DC_MODE):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-DC mode or 2-RMS mode) for" +
                              " measurement mode parameter." +
                              " Value entered: {}. ".format(mode) +
                              "Refer to help function for guidance of usage.")
        elif (dc_filter == str(dc_filter) or dc_filter != int(dc_filter)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-on or 0-off) for DC filter parameter." +
                             " Value entered: {}. ".format(dc_filter) +
                             "Refer to help function for guidance of usage.")
        elif (dc_filter > self.ON or dc_filter < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-on or 0-off) for DC filter parameter." +
                              " Value entered: {}. ".format(dc_filter) +
                              "Refer to help function for guidance of usage.")
        elif (band == str(band) or band != int(band)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-wide band or 2-narrow band) for" +
                             " measurement band parameter." +
                             " Value entered: {}. ".format(band) +
                             "Refer to help function for guidance of usage.")
        elif (band > self.NARROW_BAND or band < self.WIDE_BAND):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-wide band or 2-narrow band) for" +
                              " measurement band parameter." +
                              " Value entered: {}. ".format(band) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.rdgmode_command + str(mode) + self.comma + \
                   str(dc_filter) + self.comma + str(band)

    def q_MeasurementMode(self):
        return self.rdgmode_query

    def q_MaxMinReading(self):
        return self.rdgmnmx_query

    def q_MaxReading(self):
        return self.rdgmx_query

    def q_RelativeReading(self):
        return self.rdgrel_query

    def c_RelativeMode(self, off_on):
        if (off_on == str(off_on) or off_on != int(off_on)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 0-off or 1-on) for relative mode" +
                             " off_on parameter." +
                             " Value entered: {}. ".format(off_on) +
                             "Refer to help function for guidance of usage.")
        elif (off_on > self.ON or off_on < self.OFF):
            raise ValueError ("Enter a positive whole number (either" +
                              " 0-off or 1-on) for relative mode" +
                              " off_on parameter." +
                              " Value entered: {}. ".format(off_on) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.rel_command + str(off_on)

    def q_RelativeMode(self):
        return self.rel_query

    def c_RelayControlParameter(self, mode, alarm_type):
        if (mode == str(mode) or mode != int(mode)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 0-off, 1-on or 2-alarm) for" +
                             " relay mode parameter." +
                             " Value entered: {}. ".format(mode) +
                             "Refer to help function for guidance of usage.")
        elif (mode > self.MODE_MAX or mode < self.MODE_MIN):
            raise ValueError ("Enter a positive whole number (either" +
                              " 0-off, 1-on or 2-alarm) for" +
                              " relay mode parameter." +
                              " Value entered: {}. ".format(mode) +
                              "Refer to help function for guidance of usage.")
        elif (alarm_type == str(alarm_type) or alarm_type != int(alarm_type)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-Low alarm, 2-High alarm or 3-Both alarms) for"+
                             " relay alarm type parameter." +
                             " Value entered: {}. ".format(alarm_type) +
                             "Refer to help function for guidance of usage.")
        elif (alarm_type > self.ALARM_TYPE_MAX or
              alarm_type < self.ALARM_TYPE_MIN):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-Low alarm, 2-High alarm or 3-Both alarms)" +
                              " for relay alarm type parameter." +
                              " Value entered: {}. ".format(alarm_type) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.relay_command + str(mode) + self.comma + str(alarm_type)

    def q_RelayControlParameter(self):
        return self.relay_query

    def q_RelayStatus(self):
        return self.relayst_query

    def c_RelativeSetpoint(self, setpoint):
        if (setpoint == str(setpoint) or setpoint != int(setpoint)):
            raise TypeError ("Enter a positive whole number for relative" +
                             " setpoint parameter." +
                             " Value entered: {}. ".format(setpoint) +
                             "Refer to help function for guidance of usage.")
        else:
            return self.relsp_command + str(setpoint)

    def q_RelativeSetpoint(self):
        return self.relsp_query

    def q_ProbeType(self):
        return self.type_query

    def c_FieldUnits(self, units):
        if (units == str(units) or units != int(units)):
            raise TypeError ("Enter a positive whole number (either" +
                             " 1-Gauss, 2-Tesla, 3-Oersted or 4-Ampere/meter)" +
                             " for field units parameter." +
                             " Value entered: {}. ".format(units) +
                             "Refer to help function for guidance of usage.")
        elif (units > self.UNITS_MAX or units < self.UNITS_MIN):
            raise ValueError ("Enter a positive whole number (either" +
                              " 1-Gauss, 2-Tesla, 3-Oersted or 4-Ampere/meter)"+
                              " for field units parameter." +
                              " Value entered: {}. ".format(units) +
                              "Refer to help function for guidance of usage.")
        else:
            return self.unit_command + str(units)

    def q_FieldUnits(self):
        return self.unit_query

    def c_ClearZeroProbe(self):
        return self.zclear_command

    def q_ZeroProbe(self):
        return self.zprobe_command

    def testGaussCommand(self, command):
        if (command != str(command)):
            raise TypeError ("Enter command to test in string ('') format." +
                             " Value entered: {}. ".format(command) +
                             "Refer to help function for guidance of usage.")
        else:
            return command

    def testGaussQuery(self, query):
        if (query != str(query)):
            raise TypeError ("Enter query to test in string ('') format." +
                             " Value entered: {}. ".format(query) +
                             "Refer to help function for guidance of usage.")
        else:
            return query

    def help(self):
        print (self.newline)
        print("This is Lake Shore Model 425 gaussmeter helper function.")
        print ("Type function's number (1-46) for guidance of usage." +
               " Type 0 to exit helper function.")
        print ("q_ refers to query functions and c_ to command functions.")
        print (self.newline)
        print("Available Lake Shore Model 425 gaussmeter functions (1-46): " \
             + self.newline + \
             "1: q_ProcessLastQueryReceived" + self.newline +
             "2: q_ID" + self.newline +
             "3: c_Reset" + self.newline +
             "4: c_InputAlarmParameter" + self.newline +
             "5: q_InputAlarmParameter" + self.newline +
             "6: q_AlarmStatus" + self.newline +
             "7: c_AutoRange" + self.newline +
             "8: q_AutoRange" + self.newline +
             "9: c_AlarmAudible" + self.newline +
             "10: q_AlarmAudible" + self.newline +
             "11: c_DisplayContrast" + self.newline +
             "12: q_DisplayContrast" + self.newline +
             "13: c_FactoryDefaults" + self.newline +
             "14: q_KeypadStatus" + self.newline +
             "15: c_FrontPanelKeypadLock" + self.newline +
             "16: q_FrontPanelKeypadLock" + self.newline +
             "17: c_MaxHold" + self.newline +
             "18: q_MaxHold" + self.newline +
             "19: c_MaxHoldReset" + self.newline +
             "20: q_OperationalStatus" + self.newline +
             "21: c_ProbeFieldCompensation" + self.newline +
             "22: q_ProbeFieldCompensation" + self.newline +
             "23: q_ProbeSensitivity" + self.newline +
             "24: q_ProbeSerialNumber" + self.newline +
             "25: c_FieldRange" + self.newline +
             "26: q_FieldRange" + self.newline +
             "27: q_FieldReading" + self.newline +
             "28: c_MeasurementMode" + self.newline +
             "29: q_MeasurementMode" + self.newline +
             "30: q_MaxMinReading" + self.newline +
             "31: q_MaxReading" + self.newline +
             "32: q_RelativeReading" + self.newline +
             "33: c_RelativeMode" + self.newline +
             "34: q_RelativeMode" + self.newline +
             "35: c_RelayControlParameter" + self.newline +
             "36: q_RelayControlParameter" + self.newline +
             "37: q_RelayStatus" + self.newline +
             "38: c_RelativeSetpoint" + self.newline +
             "39: q_RelativeSetpoint" + self.newline +
             "40: q_ProbeType" + self.newline +
             "41: c_FieldUnits" + self.newline +
             "42: q_FieldUnits" + self.newline +
             "43: c_ClearZeroProbe" + self.newline +
             "44: q_ZeroProbe" + self.newline +
             "45: testGaussCommand" + self.newline +
             "46: testGaussQuery")

        while True:
            print (self.newline)
            function_number = raw_input("help >>> ")
            if (function_number == str(self.Exit)):
                print ("Exiting Lake Shore Model 425 gaussmeter" +
                       " helper function...")
                raise SystemExit
            elif (function_number == str(self.query_ProcessLastQueryReceived)):
                print ("? Process Last Query Received" + self.newline +
                       "Input: ?[terminator]" + self.newline +
                       "Return: The response of the " +
                       "last query received by the instrument." + self.newline +
                       "Remarks: Reprocesses the last " +
                       "query received by the " +
                       "instrument and sends a new response-" +
                       "this command cannot be chained " +
                       "with other commands " +
                       "and must be sent by itself.")
            elif (function_number == str(self.query_ID)):
                print ("*IDN? Identification Query" + self.newline +
                       "Input: *IDN?[term]" + self.newline +
                       "Return: <manufacturer>,<model>," +
                       "<instrument serial number>," +
                       "<firmware version>[terminator]" + self.newline +
                       "Format: s[4],s[8],s[7],n.n" + self.newline +
                       "<manufacturer> Manufacturer ID" + self.newline +
                       "<model> Instrument model number" + self.newline +
                       "<serial> Instrument serial number" + self.newline +
                       "<firmware version> Instrument " +
                       "firmware version" + self.newline +
                       "Example: LSCI,MODEL425,4250022,1.0")
            elif (function_number == str(self.command_Reset)):
                print ("*RST Reset Instrument Command" + self.newline +
                       "Input: *RST[terminator]" + self.newline +
                       "Remarks: Sets controller parameters to power-up " +
                       "settings-use the DFLT command to set defaults.")
            elif (function_number == str(self.command_InputAlarmParameter)):
                print ("ALARM Input Alarm Parameter Command" + self.newline +
                       "Input: ALARM <off/on>,<mode>,<low value>,<high value>,"+
                       "<out/in>,<alarm sort>,<audible>[term]" + self.newline +
                       "Format: n,n, +-nnn.nnnE+-nn," +
                       "+-nnn.nnnE+-nn,n,n,n" + self.newline +
                       "<off/on> Specifies alarm checking on or off: " +
                       "0 = off, 1 = on" + self.newline +
                       "<mode> Specifies checking magnitude " +
                       "(absolute value used) or algebraically " +
                       "(inlcudes sign): 1 = magnitude check, " +
                       "2 = algebraic check" + self.newline +
                       "<low value> Sets the value the source is checked " +
                       "against to activate low alarm:+-350 kG"+ self.newline +
                       "<high value> Sets the value the source is checked " +
                       "against to activate high alarm:+-350 kG"+ self.newline +
                       "<out/in> Specifies the alarm to trigger " +
                       "on value outside or inside of setpoints: 1 = outside," +
                       "2 = inside" + self.newline +
                       "<alarm sort> Turns alarm sort function on or off: " +
                       "0 = off, 1 = on" + self.newline +
                       "<audible> Specifies if the internal speaker will beep" +
                       " when an alarm condition occurs. Valid entries: " +
                       "0 = off, 1 = on" + self.newline +
                       "Example: ALARM 1,1,100,300,1,0,0[terminator]")
            elif (function_number == str(self.query_InputAlarmParameter)):
                print ("ALARM? Input Alarm Parameter Query" + self.newline +
                       "Input: ALARM?[terminator]" + self.newline +
                       "Return: <off/on>,<mode>,<low value>,<high value>," +
                       "<out/in>,<alarm sort>," +
                       "<audible> [terminator]" + self.newline +
                       "Format: n,n,+-nnn.nnnE+-nn,+-nnn.nnnE+-nn,n,n,n")
            elif (function_number == str(self.query_AlarmStatus)):
                print ("ALARMST? Alarm Status Query" + self.newline +
                       "Input: ALARMST?[terminator]" + self.newline +
                       "Return: <state>[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<state> 0 = Non-alarming, 1 = Alarming")
            elif (function_number == str(self.command_AutoRange)):
                print ("AUTO Auto Range Command" + self.newline +
                       "Input: AUTO <off/on>,[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<off/on> Specifies autorange on or off: 0 = Off," +
                       "1 = On" + self.newline +
                       "Example: AUTO 1 [term]-turns on the autorange feature.")
            elif (function_number == str(self.query_AutoRange)):
                print ("AUTO? Auto Range Query" + self.newline +
                       "Input AUTO? [terminator]" + self.newline +
                       "Return: <off/on>[terminator]" + self.newline +
                       "Format: n")
            elif (function_number == str(self.command_AlarmAudible)):
                print ("BEEP Alarm Audible Command" + self.newline +
                       "Input: BEEP <off/on>,[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<off/on> Specifies alarm audible on or off:" +
                       "0 = Off, 1 = On" + self.newline +
                       "Remarks: This command is included " +
                       "to support compatibility with the Model 455 and " +
                       "Model 475 gaussmeters-the alarm audible parameter " +
                       "is now combined with the alarm command.")
            elif (function_number == str(self.query_AlarmAudible)):
                print ("BEEP? Alarm Audible Query" + self.newline +
                       "Input: BEEP?[terminator]" + self.newline +
                       "Return: <off/on>[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "Remarks: This command is included to support " +
                       "compatibility with the Model 455 and Model " +
                       "475 gaussmeters-the alarm audible parameter is " +
                       "now combined with the alarm command.")
            elif (function_number == str(self.command_DisplayContrast)):
                print ("BRIGT Display Contrast Command" + self.newline +
                        "Input: BRIGT <contrast value>" +
                        "[terminator]" + self.newline +
                        "Format: nn" + self.newline +
                        "<contrast value> 1 to 32" + self.newline +
                        "Remarks: Sets the display contrast for the " +
                        "front panel LCD.")
            elif (function_number == str(self.query_DisplayContrast)):
                print ("BRIGT? Display Contrast Query" + self.newline +
                       "Input: BRIGT?[terminator]" + self.newline +
                       "Return: <contrast value>[terminator]" + self.newline +
                       "Format: nn")
            elif (function_number == str(self.command_FactoryDefaults)):
                print ("DFLT Factory Defaults Command" + self.newline +
                       "Input: DFLT 99[terminator]" + self.newline +
                       "Remarks: Sets all configuration values to factory " +
                       "defaults and resets the instrument-the '99' " +
                       "is included to prevent accidentally setting " +
                       "the unit to defaults.")
            elif (function_number == str(self.query_KeypadStatus)):
                print ("KEYST? Keypad Status Query" + self.newline +
                       "Input: KEYST? [terminator]" + self.newline +
                       "Return: <keypad status>[terminator]" + self.newline +
                       "Format: nn" + self.newline +
                       "Remarks: Returns a number descriptor of the last key " +
                       "pressed since the last KEYST?-KEYST? " +
                       "returns a 00 if no key pressed since last query.")
            elif (function_number == str(self.command_FrontPanelKeypadLock)):
                print ("LOCK Front Panel Keypad Lock Command" + self.newline +
                       "Input: LOCK <state>[terminator]" + + self.newline +
                       "Format: n" + self.newline +
                       "<state> 0 = Unlocked, 1 = Locked" + self.newline +
                       "Remarks: Locks out all front panel entries. " +
                       "Instrument settings can still be viewed " +
                       "but not changed.")
            elif (function_number == str(self.query_FrontPanelKeypadLock)):
                print ("LOCK? Front Panel Keypad Lock Query" + self.newline +
                       "Input: LOCK?[terminator]" + self.newline +
                       "Return: <state>,[terminator]" + self.newline +
                       "Format: n")
            elif (function_number == str(self.command_MaxHold)):
                print ("MXHOLD Max Hold Command" + self.newline +
                       "Input: MXHOLD <off/on>[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<off/on> specifies max hold on or off: 0 = Off, 1 = On"
                       + self.newline +
                       "Example: MXHOLD 1[term]-turns the max hold feature " +
                       "on-the Model 425 displays the max value.")
            elif (function_number == str(self.query_MaxHold)):
                print ("MXHOLD? Max Hold Query" + self.newline +
                       "Input: MXHOLD?[terminator]" + self.newline +
                       "Return: <off/on>[terminator]" + self.newline +
                       "Format: n")
            elif (function_number == str(self.command_MaxHoldReset)):
                print ("MXRST Max Hold Reset Command" + self.newline +
                       "Input: MXRST[terminator]" + self.newline +
                       "Remarks: Resets the stored maximum field reading " +
                       "and sets it equal to the present field reading.")
            elif (function_number == str(self.query_OperationalStatus)):
                print ("OPST? Operational Status Query" + self.newline +
                       "Input: OPST? [terminator]" + self.newline +
                       "Return: <bit weighting> [terminator]" + self.newline +
                       "Format: nnn" + self.newline +
                       "Remarks: Returns the sum of the bit weighting " +
                       "of the instrument status bits.")
            elif (function_number == str(self.command_ProbeFieldCompensation)):
                print ("PRBFCOMP Probe Field " +
                       "Compensation Command"+ self.newline +
                       "Input: PRBFCOMP <off/on>[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<off/on> Specifies probe field compensation off " +
                       "or onvalid entries: 0 = Off, 1 = On" + self.newline +
                       "Example: PRBFCOMP 1[terminator]-field measurement " +
                       "uses the probe field compensation table.")
            elif (function_number == str(self.query_ProbeFieldCompensation)):
                print ("PRBFCOMP? Probe Field " +
                       "Compensation Query" + self.newline +
                       "Input: PRBFCOMP?[terminator]" + self.newline +
                       "Return: <off/on>[term]" + self.newline +
                       "Format: n")
            elif (function_number == str(self.query_ProbeSensitivity)):
                print ("PRBSENS? Probe Sensitivity Query" + self.newline +
                       "Input: PRBSENS?[terminator]" + self.newline +
                       "Return: <sensitivity>[terminator]" + self.newline +
                       "Format: +-nnn.nnnE+-nn" + self.newline +
                       "Remarks: Returns the probe sensitivity in mV/kG.")
            elif (function_number == str(self.query_ProbeSerialNumber)):
                print ("PRBSNUM? Probe Serial Number Query" + self.newline +
                       "Input: PRBSNUM?[terminator]" + self.newline +
                       "Return: <type>[terminator]" + self.newline +
                       "Format: s[8]" + self.newline +
                       "Remarks: Returns the probe serial number.")
            elif (function_number == str(self.command_FieldRange)):
                print ("RANGE Field Range Command" + self.newline +
                       "Input: RANGE <range>[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<range> Specifies range from lowest " +
                       "to highest: 1 to 4 (field values are probe dependent)"
                       + self.newline +
                       "Example: RANGE 4[term]-sets the present range to 4.")
            elif (function_number == str(self.query_FieldRange)):
                print ("RANGE? Field Range Query" + self.newline +
                       "Input: RANGE?[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "Return: <range>[terminator]" + self.newline +
                       "Format: n")
            elif (function_number == str(self.query_FieldReading)):
                print ("RDGFIELD? Field Reading Query" + self.newline +
                       "Input: RDGFIELD?[terminator]" + self.newline +
                       "Return: <field>[terminator]" + self.newline +
                       "Format: +-nnn.nnnE+-nn" + self.newline +
                       "Remarks: Returns the field reading in a " +
                       "format based on the present units-this is valid for " +
                       "DC or RMS.")
            elif (function_number == str(self.command_MeasurementMode)):
                print ("RDGMODE Measurement Mode Command" + self.newline +
                       "Input: RDGMODE <mode>,<filter>,<band>[terminator]"
                       + self.newline +
                       "Format: n,n,n" + self.newline +
                       "<mode> Specifies the measurement mode: 1 = DC, 2 = RMS"
                       + self.newline +
                       "<filter> Turns DC filter on or off: 0 = Off, 1 = On"
                       + self.newline +
                       "<band> RMS measurement mode: 1 = wide band," +
                       "2 = narrow band" + self.newline +
                       "Example: RDGMODE 2,1,1[term]-the Model 425 is " +
                       "configured for RMS field measurement " +
                       "in wide band mode.")
            elif (function_number == str(self.query_MeasurementMode)):
                print ("RDGMODE? Measurement Mode Query" + self.newline +
                       "Input: RDGMODE?[terminator]" + self.newline +
                       "Return: <mode>,<filter>,<band>[terminator]"
                       + self.newline +
                       "Format: n,n,n")
            elif (function_number == str(self.query_MaxMinReading)):
                print ("RDGMNMX? Maximum and Minimum Reading Query"
                       + self.newline +
                       "Input: RDGMNMX?[terminator]" + self.newline +
                       "Return: <min>, <max>[terminator]" + self.newline +
                       "Format: +-nnn.nnnE+-nn, +-nnn.nnnE+-nn" + self.newline +
                       "Remarks: This command is included to support " +
                       "compatibility with the Model 455 and Model " +
                       "475 gaussmeters-in the Model 425, this query " +
                       "will always return zero for the minimum value.")
            elif (function_number == str(self.query_MaxReading)):
                print ("RDGMX? Maximum Reading Query" + self.newline +
                       "Input: RDGMX?[terminator]" + self.newline +
                       "Return: <max>[terminator]" + self.newline +
                       "Format: +-nnn.nnnE+-nn" + self.newline +
                       "Remarks: Returns the most recent maximum " +
                       "field reading.")
            elif (function_number == str(self.query_RelativeReading)):
                print ("RDGREL? Relative Reading Query" + self.newline +
                       "Input: RDGREL?[terminator]" + self.newline +
                       "Return: <relative reading>[terminator]" + self.newline +
                       "Format: +-nnn.nnnE+-nn" + self.newline +
                       "Remarks: Returns the relative field reading.")
            elif (function_number == str(self.command_RelativeMode)):
                print ("REL Relative Mode Command" + self.newline +
                       "Input: REL <off/on>[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<off/on> Specifies Relative mode off "
                       "or on: 0 = Off, 1 = On" + self.newline +
                       "Example: REL 1[term]-relative mode turned on.")
            elif (function_number == str(self.query_RelativeMode)):
                print ("REL? Relative Mode Query" + self.newline +
                       "Input: REL?[terminator]" + self.newline +
                       "Return: <off/on>[terminator]" + self.newline +
                       "Format: n")
            elif (function_number == str(self.command_RelayControlParameter)):
                print ("RELAY Relay Control Parameter Command" + self.newline +
                       "Input: RELAY <mode>,<alarm type>[terminator]"
                       + self.newline +
                       "Format: n,n" + self.newline +
                       "<mode> Specifies relay mode: 0 = Off," +
                       "1 = On, 2 = Alarm" + self.newline +
                       "<alarm type> Specifies the input alarm type that " +
                       "activates the relay when the relay is in alarm"
                       + self.newline +
                       "mode: 1 = Low alarm, 2 = High Alarm, 3 = Both Alarms"
                       + self.newline +
                       "Example: RELAY 2,1[term]-relay activates when " +
                       "low alarm activates.")
            elif (function_number == str(self.query_RelayControlParameter)):
                print ("RELAY? Relay Control Parameter Query" + self.newline +
                       "Input: RELAY?[terminator]" + self.newline +
                       "Return: <mode>,<alarm type>[terminator]"+ self.newline +
                       "Format: n,n")
            elif (function_number == str(self.query_RelayStatus)):
                print ("RELAYST? Relay Status Query" + self.newline +
                       "Input: RELAYST?[terminator]" + self.newline +
                       "Return: <status>[terminator]" + self.newline +
                       "Format: n 0 = Off, 1 = On")
            elif (function_number == str(self.command_RelativeSetpoint)):
                print ("RELSP Relative Setpoint Command" + self.newline +
                       "Input: RELSP <setpoint>[terminator]" + self.newline +
                       "Format: +-nnn.nnnE+-nn" + self.newline +
                       "<setpoint> Specifies the setpoint to use in the " +
                       "relative calculation: +-350 kG" + self.newline +
                       "Example: RELSP 1200[term]-configure the relative " +
                       "setpoint as 1200 G (if units in Gauss).")
            elif (function_number == str(self.query_RelativeSetpoint)):
                print ("RELSP? Relative Setpoint Query" + self.newline +
                       "Input: RELSP?[terminator]" + self.newline +
                       "Return: <setpoint>[terminator]" + self.newline +
                       "Format: +-nnn.nnnE+-nn")
            elif (function_number == str(self.query_ProbeType)):
                print ("TYPE? Probe Type Query" + self.newline +
                       "Input: TYPE?[terminator]" + self.newline +
                       "Return: <type>[terminator]" + self.newline +
                       "Format: nn" + self.newline +
                       "Remarks: Returns the probe type:" + self.newline +
                       "40 = high sensitivity" + self.newline +
                       "41 = high stability" + self.newline +
                       "42 = ultra-high sensitivity" + self.newline +
                       "50 = user programmable cable/high sensitivity probe"
                       + self.newline +
                       "51 = user programmable cable/high stability probe"
                       + self.newline +
                       "52 = user programmable cable/ultra-high " +
                        "sensitivitiy probe")
            elif (function_number == str(self.command_FieldUnits)):
                print ("UNIT Field Units Command" + self.newline +
                       "Input: UNIT <units>[terminator]" + self.newline +
                       "Format: n" + self.newline +
                       "<units> 1 = Gauss, 2 = Tesla, 3 = Oersted," +
                       "4 = Ampere/meter" + self.newline +
                       "Example: UNIT 2[term]-configures the Model 425 to " +
                       "report readings in Tesla.")
            elif (function_number == str(self.query_FieldUnits)):
                print ("UNIT? Field Units Query" + self.newline +
                       "Input: UNIT?[terminator]" + self.newline +
                       "Return: <units>[terminator]" + self.newline +
                       "Format: n")
            elif (function_number == str(self.command_ClearZeroProbe)):
                print ("ZCLEAR Clear Zero Probe Command" + self.newline +
                       "Input: ZCLEAR[terminator]" + self.newline +
                       "Remarks: Clears the results of the " +
                       "zero probe function.")
            elif (function_number == str(self.query_ZeroProbe)):
                print ("ZPROBE Zero Probe Command" + self.newline +
                       "Input: ZPROBE[terminator]" + self.newline +
                       "Remarks: Initiates the Zero Probe function-place " +
                       "the probe in zero gauss chamber before " +
                       "issuing this command.")
            elif (function_number == str(self.c_testGaussCommand)):
                print ("GENERAL PURPOSE TEST COMMAND" + self.newline +
                       "Input: ANY COMMAND[terminator]" + self.newline +
                       "Remarks: Test any Lakeshore Gaussmeter Model 425 " +
                       "Command in string ('') format.")
            elif (function_number == str(self.q_testGaussQuery)):
                print ("GENERAL PURPOSE TEST QUERY" + self.newline +
                       "Input: ANY QUERY[terminator]" + self.newline +
                       "Remarks: Test any Lakeshore Gaussmeter Model 425 " +
                       "Query in string ('') format.")
            else:
                raise ValueError ("Enter a positive whole number " +
                                  "(from 1 to 46) for a function guidance of " +
                                  "usage or 0 to exit helper function. " +
                                  "Value entered: {}. ".format(function_number))
