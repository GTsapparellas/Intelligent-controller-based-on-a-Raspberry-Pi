**Make sure that system is powered-on before running the program.

1) Open the terminal.
2) Point to the project's directory (e.g. $ cd Project_Directory/).
3) Run the UI version of the program by typing $ sudo python IntelligentController_UI.py 
or run the GUI version of the program by typing $ sudo python IntelligentController_GUI.py