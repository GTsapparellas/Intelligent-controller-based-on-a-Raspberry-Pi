Intelligent Controller based on a Raspberry Pi



Author: Giorgos Tsapparellas

Date: 11th August 2019

Version: 1.0



-Structure of the source code:



Project Directory/ 	IntelligentController_GUI.py
			
			IntelligentController_UI.py

			
		
			Calibration/			
							MagnetCalibration.py
			
			
			
			ControlTechniques/		PID.py

			

			Interfaces/			gpibInterface.py
							
							serialInterface.py

			

			Tuning/				PIDTuning.py

			

			UserExperience/			UI.py

			

			Utils/				Gaussmeter.py
							
							PowerSupplier.py



**All other files (e.g. __init__.py or .pyc extensions) included in the folders of project direcory are
automatically 
introduced by Python for smoothly execution of the program.



-Executing the program:



**Make sure that system is powered-on before running the program.



1) Open the terminal of Raspberry Pi.

2) Point to the project's directory (e.g. $ cd Project_Directory/).

3) Run the UI version of the program by typing $ sudo python IntelligentController_UI.py 
or run the GUI version of the program by typing $ sudo python IntelligentController_GUI.py
