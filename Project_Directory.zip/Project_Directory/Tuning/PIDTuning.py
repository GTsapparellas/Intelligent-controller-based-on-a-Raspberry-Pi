from ControlTechniques import PID

''' PIDTuning class.
    Tuning the Kp, Ki and Kd 
    parameters for PID process.
# @author: Giorgos Tsapparellas
# @date: 30 July 2019
# @version: 1.0 '''
class PIDTuning:
    ''' __init__ function for 
        initializing the 
        pid global variable used
        to instantiate the PID class. '''
    def __init__(self):
        global pid
        pid = PID.PID()
        
    ''' Tune function setting the
        Kp, Ki and Kd gains in PID class.
    #@param: Kp gain
             Ki gain
             Kd gain'''
    def Tune(self, Kp, Ki, Kd):
        pid.SetKp(Kp)
        pid.SetKi(Ki)
        pid.SetKd(Kd)
