from ControlTechniques import PID

class PIDTuning:

    def __init__(self):
        global pid
        pid = PID.PID()

    def ManualTuning(self, Kp, Ki, Kd):
        pid.SetKp(Kp)
        pid.SetKi(Ki)
        pid.SetKd(Kd)
        
    def AutoTuning(self, Kp, Ki, Kd):
        pid.SetKp(Kp)
        pid.SetKi(Ki)
        pid.SetKd(Kd)
