
from Tkinter import *
from PIL import Image, ImageTk
import sys
from Utils import Gaussmeter
from Utils import PowerSupplier
from Calibration import MagnetCalibration
from Interfaces import serialInterface
from Interfaces import gpibInterface
from ControlTechniques import PID
import time
from Tuning import PIDTuning
from math import ceil, floor

class popupWindow(object):
    def __init__(self,master):
        self.master = master
        self.master.title("User Input")
        top=self.top=Toplevel(master)
        top.geometry("250x80")
        self.l=Label(top,text="Enter desired magnetic field (Oe)")
        self.l.pack()
        self.e=Entry(top)
        self.e.pack()
        self.b=Button(top,text='Ok!',command=self.cleanup)
        self.b.pack()
        #self.ww=IntController(self.master)
        
    def cleanup(self):
        self.value=self.e.get()
        self.top.destroy()

class mainWindow(object):
    def __init__(self,master):
        global entry1, entry2
        self.master=master
        self.master.title("Intelligent Controller")
        self.master.geometry("300x250")
        self.desire_magnetic_field_reading = 0.0
        self.actual_magnetic_field_reading = 0.0
        self.current = 0.0
        self.c_current = 0.0
        self.cc_current = 0.0
        self.err = 0.0
        self.c_current_actual = 0.0
        self.current_actual = 0.0
        self.ccc_current = 0.0
        self.feedback = 0.0
        self.NUM_OF_TRIAL_ITERATIONS = 51
        
        self.pid_controller = PID.PID()
        self.power_supplier = PowerSupplier.KepcoBOP()
        self.gpib = gpibInterface.GpibInterface()
        self.gaussmeter = Gaussmeter.LakeShore425_Gauss()
        self.ser = serialInterface.SerialInterface()
        self.tuning = PIDTuning.PIDTuning()
        self.magnet_calibration = MagnetCalibration.MagnetCalibration()
        
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetRemoteCommunication(1))
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetVoltageLevel("20E0"))
        self.gpib.gpibWriteOnly(self.power_supplier.sendMultipleKepcoSCPI(self.power_supplier.c_OperatingMode("CURR"), self.power_supplier.c_EDOutput(1)))
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetCurrentLevel("3E0"))
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetCurrentLevel("0E0"))
        
        self.label1 = Label(master,text="Desired magnetic field (Oe)")
        self.label1.pack()
        
        #self.entry_text1 = ""
        #entry_text1 = StringVar()
        self.ent1=Entry(master, textvariable=entry_text1, disabledbackground="yellow", disabledforeground="red", state='disabled')
        self.ent1.pack()
        
        self.label2 = Label(master,text="Actual magnetic field (Oe)")
        self.label2.pack()
        
        #entry_text2 = ""
        #entry_text2 = StringVar()
        self.ent2=Entry(master, textvariable=entry_text2, disabledbackground="yellow", disabledforeground="red", state='disabled')
        self.ent2.pack()
        
        self.b=Button(master,text="New Entry",command=self.popup)
        self.b.pack()
        #sys.stdout.write(self.entryValue()
        self.b2=Button(master,text="Start", state="disabled", command=lambda: self.test())
        self.b2.pack()

    def popup(self):
        self.w=popupWindow(self.master)
        #self.b["state"] = "disabled"
        self.master.title("Intelligent Controller")
        self.master.geometry("300x250")
        self.master.wait_window(self.w.top)
        self.b["state"] = "normal"
        self.b2["state"] = "normal"

    def entryValue(self):
        return self.w.value
    
    def float_round(self, num, places = 0, direction = floor):
        return direction(num * (10**places)) / float(10**places)

    def test(self):
        
        #while True:
        self.desire_magnetic_field_reading = self.entryValue()
        entry_text1.set(str(self.desire_magnetic_field_reading))
        
        for i in range(1,self.NUM_OF_TRIAL_ITERATIONS):
            self.actual_magnetic_field_reading = float(self.ser.serialFullCommunication(self.gaussmeter.q_FieldReading()))
            #print(self.actual_magnetic_field_reading)
            self.err = float(self.desire_magnetic_field_reading) - float(self.actual_magnetic_field_reading)
            if (self.desire_magnetic_field_reading < self.actual_magnetic_field_reading): # descending
                self.current_actual = ((self.actual_magnetic_field_reading - self.magnet_calibration.GetA_Descending())/self.magnet_calibration.GetB_Descending())
                self.output = self.pid_controller.GenerateOutput(self.err)
                self.current = ((self.output - self.magnet_calibration.GetA_Descending())/self.magnet_calibration.GetB_Descending())
            elif(self.desire_magnetic_field_reading > self.actual_magnetic_field_reading): # ascending
                self.current_actual = ((self.actual_magnetic_field_reading - self.magnet_calibration.GetA_Ascending())/self.magnet_calibration.GetB_Ascending())
                self.output = self.pid_controller.GenerateOutput(self.err)
                self.current = ((self.output - self.magnet_calibration.GetA_Ascending())/self.magnet_calibration.GetB_Ascending())
            else:
                print("0 error. No need for further computation.")

            self.c_current = self.current_actual + self.current
            self.cc_current = self.float_round(self.c_current,2,ceil)
            self.ccc_current = str(self.cc_current) + "E0"
            self.gpib.gpibWriteOnly(self.power_supplier.c_SetCurrentLevel(self.ccc_current))
            
            time.sleep(0.1)
            
        entry_text2.set(str(self.actual_magnetic_field_reading))   
        self.b["state"] = "normal"
        self.b2["state"] = "disabled"
            

if __name__ == "__main__":
    root=Tk()
    entry_text1 = StringVar()
    entry_text2 = StringVar()
    load = Image.open("UserExperience/UoM_logo.gif")
    render = ImageTk.PhotoImage(load)
    img = Label(root, image=render)
    img.pack()
    m=mainWindow(root)
    root.mainloop()