from Utils import Gaussmeter
from Utils import PowerSupplier
from Calibration import MagnetCalibration
from Interfaces import serialInterface
from Interfaces import gpibInterface
from ControlTechniques import PID
from Tuning import PIDTuning
from Tkinter import *
from PIL import Image, ImageTk
import sys
import time
from math import ceil, floor

''' IntelligentController_GUI.py
    Main script for running
    the control program. This 
    script is using the GUI
    framework.
# @author: Giorgos Tsapparellas
# @date: 07 August 2019
# @version: 1.0 '''

''' PopUpWindow class for the GUI. '''
class PopUpWindow(object):
    ''' __init__ function for 
        initializing the pop up 
        window for the GUI.
    #@param: master '''
    def __init__(self, master):
        self.master = master
        self.master.title("User Input")
        top = self.top = Toplevel(master)
        top.geometry("250x80")
        self.labelDesirePopUp = Label(top, text="Enter desired magnetic field (Oe)")
        self.labelDesirePopUp.pack()
        self.entryDesirePopUp = Entry(top)
        self.entryDesirePopUp.pack()
        self.buttonOk = Button(top, text='Ok!', command=self.CleanUp)
        self.buttonOk.pack()
    ''' Once user input the desire magnetic field,
        get the value and destroy the window. '''
    def CleanUp(self):
        self.desireValue = self.entryDesirePopUp.get()
        self.top.destroy()
        
''' MainWindow class for the GUI. '''
class MainWindow(object):
    ''' __init__ function for 
        initializing the main 
        window for the GUI.
    #@param: master '''
    def __init__(self, master):
        
        self.master = master
        self.master.title("Intelligent Controller")
        self.master.geometry("300x250")
        
        ''' Electrical current variables. '''
        self.actual_electrical_current = 0.0
        self.feedback_electrical_current = 0.0
        self.desire_electrical_current = 0.0
        self.rounded_desire_electrical_current = 0.0
        self.string_desire_electrical_current = ""
        self.feedback_signal = 0.0
        
        ''' Process variables. '''
        self.desire_magnetic_field_reading = 0.0
        self.actual_magnetic_field_reading = 0.0
        self.error_signal = 0.0
        
        ''' Testing variables. '''
        self.NUM_OF_TRIAL_ITERATIONS = 51
        self.FIELD_UNIT = 3
        self.ON = 1
        self.OFF = 0
        self.PID_DELAY = 0.1
        self.DECIMAL_PLACES = 2
        
        ''' Initialize Kp, Ki and Kd variables for tuning purposes. '''
        self.Kp = 0.45
        self.Ki = 0.27
        self.Kd = 0.0
        
        ''' Instantiate the objects for SerialInterface,
        GpibInterface, LakeShore425_Gauss, KepcoBOP, 
        PID, PIDTuning and MagnetCalibration classes. '''
        self.pid_controller = PID.PID()
        self.power_supplier = PowerSupplier.KepcoBOP()
        self.gpib = gpibInterface.GpibInterface()
        self.gaussmeter = Gaussmeter.LakeShore425_Gauss()
        self.ser = serialInterface.SerialInterface()
        self.tuning = PIDTuning.PIDTuning()
        self.magnet_calibration = MagnetCalibration.MagnetCalibration()
        
        ''' Establish initial communication with gaussmeter and power supplier. '''
        self.ser.serialFullCommunication(self.gaussmeter.c_FieldUnits(self.FIELD_UNIT))
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetRemoteCommunication(self.ON))
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetVoltageLevel("20E0"))
        self.gpib.gpibWriteOnly(self.power_supplier.sendMultipleKepcoSCPI(self.power_supplier.c_OperatingMode("CURR"), self.power_supplier.c_EDOutput(self.ON)))
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetCurrentLevel("3E0"))
        self.gpib.gpibWriteOnly(self.power_supplier.c_SetCurrentLevel("0E0"))
        
        ''' Tune the system ready for the PID process. '''
        self.tuning.Tune(self.Kp, self.Ki, self.Kd)
        
        ''' Prepare the main window layout.
            2 labels, 2 entries and 2 buttons included. '''
        self.labelDesireMain = Label(master, text="Desired magnetic field (Oe)")
        self.labelDesireMain.pack()
        
        self.entryDesireMain = Entry(master, textvariable = entryDesireField, disabledbackground="yellow", disabledforeground="red", state='disabled')
        self.entryDesireMain.pack()
        
        self.labelActualMain = Label(master, text="Actual magnetic field (Oe)")
        self.labelActualMain.pack()

        self.entryActualMain = Entry(master, textvariable = entryActualField, disabledbackground="yellow", disabledforeground="red", state='disabled')
        self.entryActualMain.pack()
        
        self.buttonNewEntry = Button(master, text="New Entry", command=self.PopUp)
        self.buttonNewEntry.pack()

        self.buttonStart = Button(master, text="Start", state="disabled", command=lambda: self.control_loop())
        self.buttonStart.pack()
        
    ''' PopUp function calling the PopUpWindow. '''
    def PopUp(self):
        self.windowPopUp = PopUpWindow(self.master)
        self.master.title("Intelligent Controller")
        self.master.geometry("300x250")
        self.master.wait_window(self.windowPopUp.top)
        self.buttonNewEntry["state"] = "normal"
        self.buttonStart["state"] = "normal"
    
    ''' EntryValue function getting the desired magnetic field entered by the user. '''
    def EntryValue(self):
        return self.windowPopUp.desireValue
        
    ''' float_round function used to round
        common float type values to 2 decimal points precision.
    #@param: num - float number to be rounded 
         places - decimal places 
         direction - direction of the rounding '''  
    def float_round(self, num, places = 0, direction = floor):
        return direction(num * (10**places)) / float(10**places)

    ''' control_loop function. '''
    def control_loop(self):
        ''' get the user's entry of desire magnetic field. '''
        self.desire_magnetic_field_reading = self.EntryValue()
        entryDesireField.set(str(self.desire_magnetic_field_reading))
        
        ''' run 50 trials for reaching the desire magnetic field based on the feedback signal. '''
        for i in range(1,self.NUM_OF_TRIAL_ITERATIONS):
            ''' get the actual magnetic field using the hall sensor. '''
            self.actual_magnetic_field_reading = float(self.ser.serialFullCommunication(self.gaussmeter.q_FieldReading()))
            ''' calculate the initial error signal (desire_magnetic_field_reading - actual_magnetic_field_reading). '''
            self.error_signal = float(self.desire_magnetic_field_reading) - float(self.actual_magnetic_field_reading)
            ''' Split into ascending and descending for more accuracy and stability. '''
            if (self.desire_magnetic_field_reading < self.actual_magnetic_field_reading): # descending change
                ''' calculate the actual electrical current based on set magnet calibration. '''
                self.actual_electrical_current = ((self.actual_magnetic_field_reading - self.magnet_calibration.GetA_Descending())/self.magnet_calibration.GetB_Descending())
                ''' save the PID output as feedback_signal. '''
                self.feedback_signal = self.pid_controller.GenerateOutput(self.error_signal)
                ''' calculate the feedback electrical current based on set magnet calibration. '''
                self.feedback_electrical_current = ((self.feedback_signal - self.magnet_calibration.GetA_Descending())/self.magnet_calibration.GetB_Descending())
            elif(self.desire_magnetic_field_reading > self.actual_magnetic_field_reading): # ascending change
                ''' calculate the actual electrical current based on set magnet calibration. '''
                self.actual_electrical_current = ((self.actual_magnetic_field_reading - self.magnet_calibration.GetA_Ascending())/self.magnet_calibration.GetB_Ascending())
                ''' save the PID output as feedback_signal. '''
                self.feedback_signal = self.pid_controller.GenerateOutput(self.error_signal)
                ''' calculate the feedback electrical current based on set magnet calibration. '''
                self.feedback_electrical_current = ((self.feedback_signal - self.magnet_calibration.GetA_Ascending())/self.magnet_calibration.GetB_Ascending())
            else:
                ''' if there is no difference between desire_magnetic_field_reading and actual_magnetic_field_reading. '''
                self.error_signal = 0.0
            ''' add the actual_electrical_current and the feedback_electrical_current. '''
            self.desire_electrical_current = self.actual_electrical_current + self.feedback_electrical_current
            ''' round the desire_electrical_current using the float_round function. '''
            self.rounded_desire_electrical_current = self.float_round(self.desire_electrical_current,2,ceil)
            ''' convert the float desire_electrical_current value to string ready communication with the power supplier. '''
            self.string_desire_electrical_current = str(self.rounded_desire_electrical_current) + "E0"
            ''' set the current level using gpib. '''
            self.gpib.gpibWriteOnly(self.power_supplier.c_SetCurrentLevel(self.string_desire_electrical_current))
            
            ''' give some time before the next run. '''
            time.sleep(self.PID_DELAY)
        ''' set the entry of the GUI into the actual magnetic field reading. '''
        entryActualField.set(str(self.actual_magnetic_field_reading))   
        ''' enable the new entry button. '''
        self.buttonNewEntry["state"] = "normal"
        ''' disable the start button. '''
        self.buttonStart["state"] = "disabled"     

''' main function. '''
if __name__ == "__main__":
    root = Tk()
    entryDesireField = StringVar()
    entryActualField = StringVar()
    ''' add the logo image of UoM into the GUI. '''
    loadImage = Image.open("UserExperience/UoM_logo.gif")
    renderImage = ImageTk.PhotoImage(loadImage)
    imgLabel = Label(root, image = renderImage)
    imgLabel.pack()
    mainWindow = MainWindow(root)
    root.mainloop()