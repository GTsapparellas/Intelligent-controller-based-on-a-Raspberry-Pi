import time

''' PID controller.
    Kp, Ki and Kd gains should be 
    set based on manual/auto tuning.
    GenerateOutput function can then 
    be used for initiating the PID procedure.
    Integral windup is added to ensure 
    mitigation of overshooting in the system.
# @author: Giorgos Tsapparellas
# @date: 20 July 2019
# @version: 1.0 '''

class PID:
    
    ''' __init__ function for preparing the PID controller. '''
    def __init__(self):
        ''' Initialize the Kp, Ki and Kd gains. '''
        self.Kp = 0.45
        self.Ki = 0.27
        self.Kd = 0.0
        
        ''' Call the SetUp function. '''
        self.SetUp()
        
    def SetUp(self):
        ''' Initialize delta time variables. '''
        self.current_time = time.time()
        self.previous_time = self.current_time
        self.previous_error_signal = 0
        ''' Initialize proportional, integral and derivative term variables. '''
        self.Cp = 0
        self.Ci = 0
        self.Cd = 0
        ''' Initialize the integral windup guard. '''
        self.windup_guard = 1.0
    
    ''' Set the proportional gain. 
    # @param: invar - enter invar as proportional gain '''
    def SetKp(self, invar):
        self.Kp = invar

    ''' Set the integral gain. 
    # @param: invar - enter invar as integral gain '''
    def SetKi(self, invar):
        self.Ki = invar

    ''' Set the derivative gain. 
    # @param: invar - enter invar as derivative gain '''
    def SetKd(self, invar):
        self.Kd = invar
    
    ''' Get the proportional gain. 
    # @return: proportional gain as string '''
    def GetKp(self):
        return str(self.Kp)

    ''' Get the integral gain. 
    # @return: integral gain as string '''
    def GetKi(self):
        return str(self.Ki)

    ''' Get the derivative gain. 
    # @return: derivative gain as string '''
    def GetKd(self):
        return str(self.Kd)

    ''' Set the previous error signal value. 
    # @param: previous error signal '''
    def SetPrevErr(self, prev_err_sig):
        """ Set previous error value. """
        self.previous_error_signal = prev_err_sig
    
    ''' Set the windup guard. 
    # @param: windup guard '''
    def SetWindup(self, windup):
        self.windup_guard = windup
        
    ''' Performs a PID computation and returns a control value based
        on the elapsed time and the error signal.
    # @param: error signal
    # @return: PID control value '''        
    def GenerateOutput(self, error_signal):
        self.current_time = time.time()
        dt = self.current_time - self.previous_time
        de = error_signal - self.previous_error_signal
        self.Cp = self.Kp * error_signal
        self.Ci += error_signal * dt 
        
        ''' Add windup function in order to eliminate overshooting. '''
        if (self.Ci < -self.windup_guard):
            self.Ci = -self.windup_guard
        elif (self.Ci > self.windup_guard):
            self.Ci = self.windup_guard

        self.Cd = 0

        ''' Ensuring no division by 0 '''
        if dt > 0:
            self.Cd = de/dt 

        self.previous_time = self.current_time
        self.previous_error_signal = error_signal

        ''' Sum all the PID terms and return the result '''
        return self.Cp + (self.Ki * self.Ci) + (self.Kd * self.Cd)