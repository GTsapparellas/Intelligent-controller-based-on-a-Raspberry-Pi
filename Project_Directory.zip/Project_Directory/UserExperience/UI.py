from Interfaces import serialInterface
from Utils import Gaussmeter
from Calibration import MagnetCalibration
import time
import datetime

''' UI class for Intelligent Controller based on Raspberry Pi project.
# @author: Giorgos Tsapparellas
# @date: 30 July 2019
# @version: 1.0 '''

class UI:

    ''' __init__ function for constructing variables that are being 
        used from other functions of UI class '''
    def __init__(self):
        ''' set the min. and max. values
        # for desired magnetic field
        # that user can input. Notice that,
        # numbers are based on +-3 Amps current 
        # limits. For different magnet, variables
        # may be re-considered. '''
        self.DESIRE_MAGNETIC_FIELD_MAX = 847.0
        self.DESIRE_MAGNETIC_FIELD_MIN = -844.0
        
        ''' set the min. and max. values
        # for desired magnetic current limits. Notice that,
        # numbers are based on KEPCO BOP power supplier current 
        # limits. For different power supplier, variables
        # may be re-considered. '''
        self.CURRENT_LIMIT_MAX = 20.0
        self.CURRENT_LIMIT_MIN = 0.0
        
        ''' set actual and desire magnetic fields
            variables to 0. '''
        self.actual_magnetic_field = 0
        self.desire_magnetic_field = 0
        
        ''' set current limit
            variable to 0. '''
        self.current_limit = 0
        
        ''' set now_time 
            variable to the current time. '''
        self.now_time = str(datetime.datetime.now())
        
        ''' set the variables of different options
            (0 to 3). '''
        self.Exit = 0
        self.Run = 1
        self.Calibrate = 2
        self.Plot = 3
        
        ''' set newline variable
            for terminal printing purposes.'''
        self.newline = "\n"
        
        ''' set option variable
            to -1.'''
        self.option = -1
        
        ''' set the variables concerning
            enabling/disabling feature of UI.'''
        self.onoff_plot = 1
        self.ENABLE = 1
        self.DISABLE = 0
        self.plot_feature_onoff = 1
        
    ''' UserInterface function for terminal based UI. 
        Four different options for the user:
            0: Exit Program
            1: Run Program
            2: Calibrate for different magnet (default +-3 Amps)
            3: Enable/Disable plotting feature (default enabled) 
    # @return: option number '''
    def UserInterface(self):
        print("""
         _____                      _  _  _
        (_____)        _           | || |(_)                      _
           _    ____  | |_    ____ | || | _   ____   ____  ____  | |_
          | |  |  _ \ |  _)  / _  )| || || | / _  | / _  )|  _ \ |  _)
         _| |_ | | | || |__ ( (/ / | || || |( ( | |( (/ / | | | || |__
        (_____)|_| |_| \___) \____)|_||_||_| \_|| | \____)|_| |_| \___)
                                            (_____|
          ______                                    _  _
         / _____)               _                  | || |
        | /        ___   ____  | |_    ____   ___  | || |  ____   ____
        | |       / _ \ |  _ \ |  _)  / ___) / _ \ | || | / _  ) / ___)
        | \_____ | |_| || | | || |__ | |    | |_| || || |( (/ / | |
         \______) \___/ |_| |_| \___)|_|     \___/ |_||_| \____)|_|

        """)
        print("By Giorgos Tsapparellas")
        print("Version 1.0")
        print (self.newline)
        print (self.newline)
        print ("Type one of the following numbers as your chosen option: "
                + self.newline +
                "0: Exit Program" + self.newline +
                "1: Run Program" + self.newline +
                "2: Calibrate for different magnet (default +-3 Amps)" + self.newline +
                "3: Enable/Disable plotting feature (default enabled)")
        print (self.newline)
        
        option_number = raw_input("Intelligent Controller >>> ")
        
        gauss = Gaussmeter.LakeShore425_Gauss()
        ser = serialInterface.SerialInterface()
        
        if (option_number == str(self.Exit)):
            self.option = option_number
            print ("Exiting Intelligent Controller program...")
            raise SystemExit
        elif (option_number == str(self.Run)):
            print (self.newline)
            self.actual_magnetic_field = ser.serialFullCommunication(gauss.q_FieldReading())
            self.now_time = str(datetime.datetime.now())
            print("Actual magnetic field (Oe): {} ".format(float(self.actual_magnetic_field)) +
                  "(" + self.now_time + ")")
            print (self.newline)
            self.desire_magnetic_field = raw_input ("Enter the Desired Magnetic " +
                                               "Field (Oe): ")
            if (self.desire_magnetic_field.isalpha()):
                raise TypeError ("Enter a desire magnetic field (Oe) in number"+
                                 " format (int or decimal). Value entered:" +
                                 " {}. ".format(self.desire_magnetic_field))
            elif (float(self.desire_magnetic_field) > self.DESIRE_MAGNETIC_FIELD_MAX
                                              or
                 float(self.desire_magnetic_field) < self.DESIRE_MAGNETIC_FIELD_MIN):
                raise ValueError ("Enter a desire magnetic field (Oe) between "+
                                  "{}".format(self.DESIRE_MAGNETIC_FIELD_MIN) +
                                  " and {}".format(self.DESIRE_MAGNETIC_FIELD_MAX) +", inclusively."+
                                  " Value entered: " +
                                  "{}. ".format(float(self.desire_magnetic_field)))
            else:
                self.option = option_number
                print("Wait...")
        elif (option_number == str(self.Calibrate)):
            print (self.newline)
            print("Default magnet calibration (current limit) is set to +- 3 Amps. IMPORTANT: Keep system ON during magnet calibration.")
            print (self.newline)
            self.current_limit = raw_input ("Enter the current limit " +
                                               "for magnet calibration (e.g. 5): ")
            if (self.current_limit.isalpha()):
                raise TypeError ("Enter a positive current limit (Amps) for magnet calibration in number"+
                                 " format (int or decimal). Value entered:" +
                                 " {}. ".format(self.current_limit))
            elif (float(self.current_limit) > self.CURRENT_LIMIT_MAX
                                              or
                 float(self.current_limit) <= self.CURRENT_LIMIT_MIN):
                raise ValueError ("Enter a positive current limit (Amps) for magnet calibration "+
                                  " no bigger than {}".format(self.CURRENT_LIMIT_MAX) +", inclusively."+
                                  " Value entered: " +
                                  "{}. ".format(float(self.current_limit)))
            else:
                self.option = option_number
                print("Wait...")
                print("This might take a while...")
        elif (option_number == str(self.Plot)):
            print (self.newline)
            print("By default plotting feature is enabled.")
            print (self.newline)
            self.onoff_plot = raw_input ("Enter 1 for enabling and 0 for disabling the plotting feature: ")
            if (self.onoff_plot.isalpha()):
                raise TypeError ("Enter a positive whole number (either" +
                                 " 0-disable or 1-enable) for" +
                                 " disabling/enabling the plotting feature." +
                                 " Value entered: {}. ".format(int(self.onoff_plot)))
            elif (int(self.onoff_plot) > self.ENABLE or int(self.onoff_plot) < self.DISABLE):
                raise ValueError ("Enter a positive whole number (either" +
                                 " 0-disable or 1-enable) for" +
                                 " disabling/enabling the plotting feature." +
                                 " Value entered: {}. ".format(int(self.onoff_plot)))
            else:
                self.option = option_number
                print("Wait...")
                self.plot_feature_onoff = int(self.onoff_plot)
            
        else:
            raise ValueError ("Enter a whole number (from list) " +
                              "as chosen option. " +
                              "Value entered: {}. ".format(option_number))
        return self.option

    ''' GetOptionNumber function getting the option number
        selected by the user. 
    # @return: option '''
    def GetOptionNumber(self):
        return self.option
        
    ''' GetDesiredMagneticField function getting the field
        value entered by the user. 
    # @return: desire magnetic field  '''
    def GetDesiredMagneticField(self):
        return float(self.desire_magnetic_field)
    
    ''' GetCurrentLimit function getting the current limit
        value entered by the user for magnet calibration. 
    # @return: current limit '''
    def GetCurrentLimit(self):
        return float(self.current_limit)

    ''' GetPlotFeatureOnOff function getting the selection
        of user for enabling/disabling plotting option. 
    # @return: plot feature on/off '''
    def GetPlotFeatureOnOff(self):
        return self.plot_feature_onoff