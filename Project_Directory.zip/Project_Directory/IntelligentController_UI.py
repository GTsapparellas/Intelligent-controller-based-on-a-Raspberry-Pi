from Utils import Gaussmeter
from Utils import PowerSupplier
from Calibration import MagnetCalibration
from Interfaces import serialInterface
from Interfaces import gpibInterface
from ControlTechniques import PID
from UserExperience import UI
from Tuning import PIDTuning
from math import ceil, floor
import matplotlib.pyplot as plt
import time
import datetime

''' IntelligentController_UI.py
    Main script for running
    the control program. This 
    script is using the UI
    framework.
# @author: Giorgos Tsapparellas
# @date: 07 August 2019
# @version: 1.0 '''

def setup():
    global option, newline, DECIMAL_PLACES, CALIBRATION_DELAY, PID_DELAY, FIELD_UNIT
    global RunOption, CalibrationOption, PlotOption
    global start_time, now_time, elapsed_time
    global actual_electrical_current, feedback_electrical_current, desire_electrical_current, rounded_desire_electrical_current, string_desire_electrical_current
    global setpoint_list,  time_list, output_list
    global desire_magnetic_field_reading, actual_magnetic_field_reading, error_signal
    global NUM_OF_TRIAL_ITERATIONS, ON, OFF
    global user_interface, ser, gpib, gaussmeter, power_supplier, pid_controller, tuning, magnet_calibration 
    global Kp, Ki, Kd
    
    newline = "\n"
    DECIMAL_PLACES = 2
    CALIBRATION_DELAY = 2
    PID_DELAY = 0.1
    FIELD_UNIT = 3
    
    ''' Available options. '''
    RunOption = "1"
    CalibrationOption = "2"
    PlotOption = "3"
    
    ''' Timing variables. '''
    start_time = 0.0
    now_time = 0.0
    elapsed_time = 0.0
    
    ''' Electrical current variables. '''
    actual_electrical_current = 0.0
    feedback_electrical_current = 0.0
    desire_electrical_current = 0.0
    rounded_desire_electrical_current = 0.0
    string_desire_electrical_current = ""
    
    ''' Lists for plotting purposes. '''
    setpoint_list = []
    time_list = []
    output_list = []
    
    ''' Process variables. '''
    desire_magnetic_field_reading = 0.0
    actual_magnetic_field_reading = 0.0
    error_signal = 0.0

    ''' Testing variables. '''
    NUM_OF_TRIAL_ITERATIONS = 51
    ON = 1
    OFF = 0
    
    ''' Initialize Kp, Ki and Kd variables for tuning purposes. '''
    Kp = 0.45
    Ki = 0.27
    Kd = 0.0
    
    ''' Instantiate the objects for UI, SerialInterface,
    GpibInterface, LakeShore425_Gauss, KepcoBOP, 
    PID, PIDTuning and MagnetCalibration classes. '''
    user_interface = UI.UI()
    ser = serialInterface.SerialInterface()
    gpib = gpibInterface.GpibInterface()
    gaussmeter = Gaussmeter.LakeShore425_Gauss()
    power_supplier = PowerSupplier.KepcoBOP()
    pid_controller = PID.PID()
    tuning = PIDTuning.PIDTuning()
    magnet_calibration = MagnetCalibration.MagnetCalibration()
    
    ''' Establish initial communication with gaussmeter and power supplier. '''
    ser.serialFullCommunication(gaussmeter.c_FieldUnits(FIELD_UNIT))
    gpib.gpibWriteOnly(power_supplier.c_SetRemoteCommunication(ON))
    gpib.gpibWriteOnly(power_supplier.c_SetVoltageLevel("20E0"))
    gpib.gpibWriteOnly(power_supplier.sendMultipleKepcoSCPI(power_supplier.c_OperatingMode("CURR"), power_supplier.c_EDOutput(ON)))
    gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel("3E0"))
    gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel("0E0"))
    
    ''' Tune the system ready for the PID process. '''
    tuning.Tune(Kp, Ki, Kd)

''' float_round function used to round
    common float type values to 2 decimal points precision.
#@param: num - float number to be rounded 
         places - decimal places 
         direction - direction of the rounding ''' 
def float_round(num, places = 0, direction = floor):
    return direction(num * (10**places)) / float(10**places)

''' control_loop function. '''
def control_loop():
    ''' call the setup function prior entering in the while loop. '''
    setup()
    ''' run this "forever", until otherwise prompted by the user. '''
    while True:
        ''' start the UI and get the user's selected option. '''
        user_interface.UserInterface()
        option = user_interface.GetOptionNumber()
        ''' if user selects to run the control program. '''
        if (option == RunOption):
            desire_magnetic_field_reading = user_interface.GetDesiredMagneticField()
            # start the timer (milliseconds)
            start_time = int(round(time.time() * 1000))
            ''' run 50 trials for reaching the desire magnetic field based on the feedback signal. '''
            for i in range(1,NUM_OF_TRIAL_ITERATIONS):
                ''' get the actual magnetic field using the hall sensor. '''
                actual_magnetic_field_reading = float(ser.serialFullCommunication(gaussmeter.q_FieldReading()))
                ''' calculate the initial error signal (desire_magnetic_field_reading - actual_magnetic_field_reading). '''
                error_signal = float(desire_magnetic_field_reading) - float(actual_magnetic_field_reading)
                ''' Split into ascending and descending for more accuracy and stability. '''
                if (desire_magnetic_field_reading < actual_magnetic_field_reading): # descending change
                    ''' calculate the actual electrical current based on set magnet calibration. '''
                    actual_electrical_current = ((actual_magnetic_field_reading - magnet_calibration.GetA_Descending())/magnet_calibration.GetB_Descending())
                    ''' save the PID output as feedback_signal. '''
                    feedback_signal = pid_controller.GenerateOutput(error_signal)
                    ''' calculate the feedback electrical current based on set magnet calibration. '''
                    feedback_electrical_current = ((feedback_signal - magnet_calibration.GetA_Descending())/magnet_calibration.GetB_Descending())
                elif(desire_magnetic_field_reading > actual_magnetic_field_reading): # ascending change
                    ''' calculate the actual electrical current based on set magnet calibration. '''
                    actual_electrical_current = ((actual_magnetic_field_reading - magnet_calibration.GetA_Ascending())/magnet_calibration.GetB_Ascending())
                    ''' save the PID output as feedback_signal. '''
                    feedback_signal = pid_controller.GenerateOutput(error_signal)
                    ''' calculate the feedback electrical current based on set magnet calibration. '''
                    feedback_electrical_current = ((feedback_signal - magnet_calibration.GetA_Ascending())/magnet_calibration.GetB_Ascending())
                else:
                    ''' if there is no difference between desire_magnetic_field_reading and actual_magnetic_field_reading. '''
                    error_signal = 0.0
                 
                ''' add the actual_electrical_current and the feedback_electrical_current. ''' 
                desire_electrical_current = actual_electrical_current + feedback_electrical_current
                ''' round the desire_electrical_current using the float_round function. '''
                rounded_desire_electrical_current = float_round(desire_electrical_current,DECIMAL_PLACES,ceil)
                ''' convert the float desire_electrical_current value to string ready communication with the power supplier. '''
                string_desire_electrical_current = str(rounded_desire_electrical_current) + "E0"
                ''' set the current level using gpib. '''
                gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel(string_desire_electrical_current))
                ''' give some time before the next run. '''
                time.sleep(PID_DELAY)

                # end the timer (milliseconds)
                elapsed_time = (int(round(time.time() * 1000)) - start_time)
                
                ''' if the plotting feature is enabled, append set-point, times and control output
                    to the related lists. '''
                if (user_interface.GetPlotFeatureOnOff() == ON):
                    setpoint_list.append(desire_magnetic_field_reading)
                    time_list.append(elapsed_time)
                    output_list.append(actual_magnetic_field_reading)
            ''' Output the actual_magnetic_field_reading to the user. '''
            output_actual_magnetic_field = ser.serialFullCommunication(gaussmeter.q_FieldReading())
            now_time = str(datetime.datetime.now())
            print (newline)
            print("Output - Actual magnetic field (Oe): {} ".format(float(output_actual_magnetic_field)) +
                  "(" + now_time + ")")
            ''' if plot feature is enabled, plot the controlled procedure investigated. '''
            if (user_interface.GetPlotFeatureOnOff() is ON):
                fig = plt.figure()

                plt.plot(time_list, output_list, 'g', label='Control output', linewidth = 1)
                plt.plot(time_list, setpoint_list, 'r--', label='Desired set-point', linewidth = 1.5)

                plt.xlabel('time (ms)')
                plt.ylabel('Magnetic Field (Oe)')
                plt.title('PID Controller - Auto Tuning (Ziegler and Nichols)\n' + 'Speed Optimization\n' 'P: ' + pid_controller.GetKp() +', '+ 'I: ' + pid_controller.GetKi() +', ' + 'D: ' + pid_controller.GetKd())
                plt.grid(True)
                plt.legend(loc='best')
                plt.show()
        # ''' if user selects to calibrate the system for another magnet. '''      
        elif (option == CalibrationOption):
            magnet_calibration.SetPositiveCurrentLimit(user_interface.GetCurrentLimit())
            magnet_calibration.SetNegativeCurrentLimit(user_interface.GetCurrentLimit())
            magnet_calibration.desceding_calibration()
            time.sleep(CALIBRATION_DELAY)
            magnet_calibration.asceding_calibration()
            print("Magnet calibration done.")
            print("Information: ")
            print("a_ascending = {}".format(magnet_calibration.GetA_Ascending()))
            print("b_ascending = {}".format(magnet_calibration.GetB_Ascending()))
            print("a_descending = {}".format(magnet_calibration.GetA_Descending()))
            print("b_descending = {}".format(magnet_calibration.GetB_Descending()))
        # ''' if the user selects to enable or disable the plot feature. '''
        elif (option == PlotOption):
            if (user_interface.GetPlotFeatureOnOff() is ON):
                print("Plot feature is enabled.")
            else:
                print("Plot feature is disbled.")
                
''' main function. '''
if __name__ == "__main__":
    control_loop()

