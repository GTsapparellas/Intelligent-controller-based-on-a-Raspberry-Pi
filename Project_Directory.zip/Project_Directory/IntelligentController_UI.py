from Utils import Gaussmeter
from Utils import PowerSupplier
from Calibration import MagnetCalibration
from Interfaces import serialInterface
from Interfaces import gpibInterface
from ControlTechniques import PID
from UserExperience import UI
import time
from Tuning import PIDTuning
from math import ceil, floor
import matplotlib.pyplot as plt
import numpy as np
import scipy
from scipy.interpolate import spline
import datetime

def float_round(num, places = 0, direction = floor):
    return direction(num * (10**places)) / float(10**places)

def test():
    global option, elapsed_time, num_of_trial_iterations, newline, start_time, now_time, seconds, feedback, feedback_list, time_list, setpoint_list, desire_magnetic_field_reading, actual_magnetic_field_reading, current, current_actual, c_current_actual, c_current, cc_current, ccc_current, err
    desire_magnetic_field_reading = 0.0
    actual_magnetic_field_reading = 0.0
    current = 0.0
    c_current = 0.0
    cc_current = 0.0
    err = 0.0
    c_current_actual = 0.0
    current_actual = 0.0
    ccc_current = 0.0
    feedback = 0.0
    start_time = 0.0
    now_time = 0.0
    seconds = 0.0
    elapsed_time = 0
    newline = "\n"

    feedback_list = []
    time_list = []
    setpoint_list = []
    elapsed_time_list = []
    
    NUM_OF_TRIAL_ITERATIONS = 51
    
    pid_controller = PID.PID()
    user_interface = UI.UI()
    power_supplier = PowerSupplier.KepcoBOP()
    gpib = gpibInterface.GpibInterface()
    gaussmeter = Gaussmeter.LakeShore425_Gauss()
    ser = serialInterface.SerialInterface()
    tuning = PIDTuning.PIDTuning()
    magnet_calibration = MagnetCalibration.MagnetCalibration()
    #graphical_user_interface = GUI.GUI()
    #g.clicked()

    gpib.gpibWriteOnly(power_supplier.c_SetRemoteCommunication(1))
    gpib.gpibWriteOnly(power_supplier.c_SetVoltageLevel("20E0"))
    gpib.gpibWriteOnly(power_supplier.sendMultipleKepcoSCPI(power_supplier.c_OperatingMode("CURR"), power_supplier.c_EDOutput(1)))
    gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel("3E0"))
    gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel("0E0"))
    
    while True:
        user_interface.UserInterface()
        option = user_interface.GetOptionNumber()
        
        if (option == "1"):
            desire_magnetic_field_reading = user_interface.GetDesiredMagneticField()
            start_time = int(round(time.time() * 1000))
            for i in range(1,NUM_OF_TRIAL_ITERATIONS):
                actual_magnetic_field_reading = float(ser.serialFullCommunication(gaussmeter.q_FieldReading()))
                err = float(desire_magnetic_field_reading) - float(actual_magnetic_field_reading)
                if (desire_magnetic_field_reading < actual_magnetic_field_reading): # descending
                    current_actual = ((actual_magnetic_field_reading - magnet_calibration.GetA_Descending())/magnet_calibration.GetB_Descending())
                    output = pid_controller.GenerateOutput(err)
                    current = ((output - magnet_calibration.GetA_Descending())/magnet_calibration.GetB_Descending())
                elif(desire_magnetic_field_reading > actual_magnetic_field_reading): # ascending
                    current_actual = ((actual_magnetic_field_reading - magnet_calibration.GetA_Ascending())/magnet_calibration.GetB_Ascending())
                    output = pid_controller.GenerateOutput(err)
                    current = ((output - magnet_calibration.GetA_Ascending())/magnet_calibration.GetB_Ascending())
                else:
                    print("0 error. No need for further computation.")

                c_current = current_actual + current
                cc_current = float_round(c_current,2,ceil)
                ccc_current = str(cc_current) + "E0"
                gpib.gpibWriteOnly(power_supplier.c_SetCurrentLevel(ccc_current))
                
                time.sleep(0.1)

                elapsed_time = (int(round(time.time() * 1000)) - start_time)
                
                if (user_interface.GetPlotFeatureOnOff() == 1):
                    setpoint_list.append(desire_magnetic_field_reading)
                    time_list.append(elapsed_time)
                    feedback_list.append(actual_magnetic_field_reading)
            
            actual_magnetic_field = ser.serialFullCommunication(gaussmeter.q_FieldReading())
            now_time = str(datetime.datetime.now())
            print (newline)
            print("Output - Actual magnetic field (Oe): {} ".format(float(actual_magnetic_field)) +
                  "(" + now_time + ")")
            if (user_interface.GetPlotFeatureOnOff() is 1):
                fig = plt.figure()

                plt.plot(time_list, feedback_list, 'g', label='Actual output', linewidth = 1)
                plt.plot(time_list, setpoint_list, 'r--', label='Desired set-point', linewidth = 1.5)

                plt.xlabel('time (ms)')
                plt.ylabel('Magnetic Field (Oe)')
                plt.title('PID Controller\n' + 'P: ' + pid_controller.GetKp() +', '+ 'I: ' + pid_controller.GetKi() +', ' + 'D: ' + pid_controller.GetKd())
                plt.grid(True)
                plt.legend(loc='best')
                plt.show()
                
        elif (option == "2"):
            magnet_calibration.SetPositiveCurrentLimit(user_interface.GetCurrentLimit())
            magnet_calibration.SetNegativeCurrentLimit(user_interface.GetCurrentLimit())
            magnet_calibration.desceding_calibration()
            time.sleep(2)
            magnet_calibration.asceding_calibration()
            print("Magnet calibration done.")
            print("Information: ")
            print("a_ascending = {}".format(magnet_calibration.GetA_Ascending()))
            print("b_ascending = {}".format(magnet_calibration.GetB_Ascending()))
            print("a_descending = {}".format(magnet_calibration.GetA_Descending()))
            print("b_descending = {}".format(magnet_calibration.GetB_Descending()))
        elif (option == "3"):
            if (user_interface.GetPlotFeatureOnOff() is 1):
                print("Plot feature is enabled.")
            else:
                print("Plot feature is disbled.")

if __name__ == "__main__":
    test()
