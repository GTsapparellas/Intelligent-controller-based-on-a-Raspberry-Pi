import Gpib
import time

''' GpibInterface class for Intelligent Controller based on Raspberry Pi project.
# @author: Giorgos Tsapparellas
# @date: 30 June 2019
# @version: 1.0 '''

class GpibInterface:

    ''' __init__ function for establishing initial gpib
        communication with address 0,6 using Python Gpib library '''
    def __init__(self):
        self.gpibInterface = Gpib.Gpib(0, 6)
        self.messageTerminator = "\n"
        
    ''' gpibFullCommunication function writes and reads a command/query using
        Python Gpib library.
    # @param: command_query - enter command/query to write '''
    def gpibFullCommunication(self, command_query):
        try:
            self.gpibInterface.write(command_query + self.messageTerminator)
            time.sleep(0.03)
            reading = self.gpibInterface.read(100)
            return str(reading)
        except Exception:
            raise Exception ("Gpib communication error" +
                             " (cannot write/read).")
        
    ''' gpibWriteOnly function writes a command/query using
        Python Gpib library.
    # @param: command_query - enter command/query to write '''
    def gpibWriteOnly(self, command_query):
        try:
            writing = self.gpibInterface.write(command_query + self.messageTerminator)
            time.sleep(0.03)
            return str(writing)
        except Exception:
            raise Exception ("Gpib communication error" +
                             " (cannot write/read).")
