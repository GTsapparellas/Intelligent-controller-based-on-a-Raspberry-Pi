import serial
import time

''' SerialInterface class for Intelligent Controller based on Raspberry Pi project.
# @author: Giorgos Tsapparellas
# @date: 30 June 2019
# @version: 1.0 '''

class SerialInterface:

    ''' __init__ function for establishing initial serial
    communication with ttyUSB0 using Python serial library '''
    def __init__(self):
        self.serialInterface = serial.Serial("/dev/ttyUSB0",
                    baudrate = 57600,
                    bytesize = serial.SEVENBITS,
                    parity = serial.PARITY_ODD,
                    stopbits = serial.STOPBITS_ONE,
                    timeout = 0.1,
                    xonxoff = False,
                    rtscts = False,
                    dsrdtr = False
                    )
        self.messageTerminators = "\r\n"
        
    ''' serialFullCommunication function writes and reads
        a command/query using Python serial library.
    # @param: command_query - enter command/query to write '''
    def serialFullCommunication(self, command_query):
        if self.serialInterface.isOpen():
            try:
                self.serialInterface.flushInput()
                self.serialInterface.flushOutput()
                self.serialInterface.write(command_query +
                                           self.messageTerminators)
                time.sleep(0.03)
                reading = ''
                while self.serialInterface.inWaiting():
                    reading += self.serialInterface.read()
                return str(reading)
            except Exception:
                raise Exception ("Serial communication error" +
                                 " (cannot write/read).")
        else:
            raise Exception ("Cannot open serial port.")
        self.serialInterface.close()
        
    ''' serialWriteOnly function writes
        a command/query using Python serial library.
    # @param: command_query - enter command/query to write '''
    def serialWriteOnly(self, command_query):
        if self.serialInterface.isOpen():
            try:
                self.serialInterface.flushInput()
                self.serialInterface.flushOutput()
                writing = self.serialInterface.write(command_query +
                                                     self.messageTerminators)
                time.sleep(0.03)
                return str(writing)
            except Exception:
                raise Exception ("Serial communication error" +
                                 " (cannot write/read).")
        else:
            raise Exception ("Cannot open serial port.")
        self.serialInterface.close()
